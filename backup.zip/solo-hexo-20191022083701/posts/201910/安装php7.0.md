title: 安装 - php7.0
date: '2019-10-22 07:39:39'
updated: '2019-10-22 07:39:39'
tags: [安装部署]
permalink: /articles/2019/10/22/1571729979073.html
---
```
yum install -y bzip2-devel libmcrypt-devel libmhash-devel net-snmp-devel gcc libtool-ltdl-devel patch libxml2 libxml2-devel curl curl-devel libjpeg libpng freetype-devel libjpeg-devel libpng-devel freetype-devel epel-release libmcrypt-devel autoconf m4
```
### /etc/nginx/fastcgi.conf
```
+fastcgi_pass   php-fpm;
+#fastcgi_index  index.php;

-fastcgi_param  SCRIPT_FILENAME    $document_root$fastcgi_script_name;
+set $path_info "";
+set $real_script_name $fastcgi_script_name;
+if ($fastcgi_script_name ~ "^(.+?\.php)(/.+)$") {
+set $real_script_name $1;
+set $path_info $2;
+}
+fastcgi_param SCRIPT_FILENAME $document_root$real_script_name;
+fastcgi_param SCRIPT_NAME $real_script_name;
+fastcgi_param PATH_INFO $path_info;
+
+# fastcgi_param  SCRIPT_FILENAME    $document_root$fastcgi_script_name;
 fastcgi_param  QUERY_STRING       $query_string;
 fastcgi_param  REQUEST_METHOD     $request_method;
 fastcgi_param  CONTENT_TYPE       $content_type;
 fastcgi_param  CONTENT_LENGTH     $content_length;

-fastcgi_param  SCRIPT_NAME        $fastcgi_script_name;
+# fastcgi_param  SCRIPT_NAME        $fastcgi_script_name;
 fastcgi_param  REQUEST_URI        $request_uri;
 fastcgi_param  DOCUMENT_URI       $document_uri;
 fastcgi_param  DOCUMENT_ROOT      $document_root;
```

```
'./configure'  '--prefix=/usr/local/php-fpm/' '--with-config-file-path=/usr/local/php-fpm/etc/' '--with-libxml-dir' '--with-jpeg-dir' '--with-gd' '--with-mcrypt' '--with-iconv' '--enable-sockets' '--with-png-dir' '--with-mhash' '--enable-soap' '--enable-mbstring=all' '--enable-bcmath' '--with-bz2' '--with-curl' '--with-snmp' '--with-pcre-dir' '--enable-opcache' '--with-mysqli' '--with-pdo-mysql' '--enable-fpm' '--with-freetype-dir' '--enable-zip' '--enable-sysvsem' '--enable-mbstring' '--enable-libxml' '--enable-xml' '--with-openssl'
make
make install
```
### [redis扩展](http://pecl.php.net/get/redis-4.0.2.tgz)
```
/usr/local/php-fpm/bin/phpize  
./configure --with-php-config=/usr/local/php-fpm/bin/php-config  
make && make install
```
### /usr/local/php-fpm/etc/php.ini
```
[PHP]
# 是否要求PHP输出层在每个输出块之后自动刷新数据。
implicit_flush = Off
max_execution_time = 30
max_input_time = 30
error_reporting = E_ALL & ~E_DEPRECATED & ~E_NOTICE
# 是否将错误信息作为输出的一部分显示，开发环境On
display_errors = Off
display_startup_errors = Off
# 是否在日志文件里记录错误，具体在哪里记录取决于error_log指令。
log_errors = On
# 设置错误日志中附加的与错误信息相关联的错误源的最大长度。
log_errors_max_len = 1024
# 记录错误日志时是否忽略重复的错误信息。
ignore_repeated_errors = Off
# 是否在忽略重复的错误信息时忽略重复的错误源。
ignore_repeated_source = Off
# 是否报告内存泄漏。
report_memleaks = On
# 错误日志文件
error_log = /var/log/php-fpm/php.log
# PHP注册 Environment, GET, POST, Cookie, Server 变量的顺序。 分别用 E, G, P, C, S 表示，按从左到右注册，新值覆盖旧值。
variables_order = "GPCS"
register_argc_argv = Off
# 允许的POST数据最大字节长度。此设定也影响到文件上传。
post_max_size = 50M
default_mimetype = "text/html"
# 是否允许HTTP文件上传。
file_uploads = On
upload_max_filesize = 50M
default_socket_timeout = 10

[CLI Server]
cli_server.color = On
[Date]
date.timezone = Asia/Shanghai
[Pdo_mysql]
pdo_mysql.cache_size = 2000
pdo_mysql.default_socket=
[Session]
session.save_handler = files
session.save_path = /tmp
session.use_strict_mode = 0
session.use_cookies = 1
session.use_only_cookies = 1
session.name = PHPSESSID
session.auto_start = 0
session.cookie_lifetime = 0
session.cookie_path = /
session.cookie_domain =
session.cookie_httponly =
session.serialize_handler = php
session.gc_probability = 1
session.gc_divisor = 1000
session.gc_maxlifetime = 1440
session.referer_check =
session.cache_limiter = nocache
session.cache_expire = 180
session.use_trans_sid = 0
session.hash_function = 0
session.hash_bits_per_character = 5
url_rewriter.tags = "a=href,area=href,frame=src,input=src,form=fakeentry"
[Tidy]
tidy.clean_output = Off
[opcache]
zend_extension=opcache.so
# 开启OR关闭
opcache.enable=0
opcache.enable_cli=0
opcache.error_log=/var/log/php-fpm/opcache.log

extension=redis.so
```
### /usr/local/php-fpm/etc/php-fpm.conf
```
[global]
pid = /var/run/php-fpm.pid
error_log = /var/log/php-fpm/fpm.log
log_level = error
rlimit_files = 65535

[www]
user = dev
group = dev

listen = 127.0.0.1:9000
;listen = /var/run/php-fpm.sock

;listen.backlog = 1024
listen.mode = 0666

pm = static
pm.max_children = 300
pm.process_idle_timeout = 10s;
pm.max_requests = 10240

pm = dynamic
pm.max_children = 100
pm.start_servers = 15
pm.min_spare_servers = 10
pm.max_spare_servers = 100
pm.process_idle_timeout = 15s;
pm.max_requests = 10240
pm.status_path = /fpm_status
slowlog = /var/log/php-fpm/$pool.slow.log
request_slowlog_timeout = 2s
request_terminate_timeout = 60s
```

### /etc/systemd/system/php-fpm.service
```
[Unit]  
Description=nginx service  
After=network.target

[Service]  
Type=forking  
ExecStart=/usr/local/php-fpm/sbin/php-fpm  
ExecStop=kill $(cat /var/run/php-fpm/php-fpm.pid)  
PrivateTmp=true
LimitNOFILE=65535
LimitNPROC=65535

[Install]  
WantedBy=multi-user.target
```

### /etc/systemd/system/nginx.service
```
[Unit]
Description=nginx service
After=network.target

[Service]
Type=forking
User=dev
ExecStart=/opt/app/nginx/sbin/nginx -c /opt/conf/nginx/tmp/nginx.conf
ExecReload=/opt/app/nginx/sbin/nginx -s reload
ExecStop=/opt/app/nginx/sbin/nginx -s quit
PrivateTmp=true
LimitNOFILE=65535
LimitNPROC=65535

[Install]
WantedBy=multi-user.target
```

```
systemctl enable php-fpm
systemctl enable nginx
```
