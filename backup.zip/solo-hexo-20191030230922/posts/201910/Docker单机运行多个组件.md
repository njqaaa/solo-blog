title: !!binary |-
  RG9ja2VyIC0g5Y2V5py6COi/kOihjOWkmuS4que7hOS7tg==
date: '2019-10-24 14:38:29'
updated: '2019-10-24 19:04:02'
tags: [Docker]
permalink: /articles/2019/10/24/1571899109486.html
---
* 场景

  * dev/test 环境需要各种第三方组件
  * 资源隔离
* 功能

  * 创建随机密码
  * 持久化至本地
    * 使用 -p 映射端口至本地
* 当前支持的组件 list

  * Redis
  * zookeeper
  * kafka
  * Memcached
  * consul
  * Elasticsearch
  * mongo
* 容器列表

  * 创建 container-list
  * 第一列：镜像名 +tag
  * 第二列：环境
  * 第三列：应用名
  * 第四列：映射至本地的端口号

##### demo 如下

```
consul:1.3 test public 28500 
memcached:1.5.11 online wikios 51211
mongo:4.0.6 online yapi 27017
mongo:4.0.6 online web-monitor 27018
redis:3.0 online wikios 56379
redis:3.0 online dock 46379
redis:3.0 online sops 46380
redis:3.0 online 4s 46381
consul:1.3 dev public 18500
consul:1.3 test public 28500
memcached:1.5.11 online wikios 51211
zookeeper:3.5 dev common 12181
zookeeper:3.5 test common 22181
wurstmeister/kafka:2.11-0.11.0.3 dev common 19092
wurstmeister/kafka:2.11-0.11.0.3 test common 29092
```

### 脚本

```
#!/bin/bash
container_list_file="/opt/bin/container-list"
local_ip=$(/sbin/ifconfig -a|grep inet|grep 10.111|grep -v inet6|awk '{print $2}'|head -n 1)
es_memory="4096m"
while read line
do
    line=($line)
    image_name=${line[0]}
    env=${line[1]}
    project_name=${line[2]}
    node_port=${line[3]}
    type_name=$(echo ${image_name} | awk -F ':' '{print $1}' | awk -F '/' '{print $NF}')
    data_path="/opt/${type_name}/data/${env}-${project_name}"
    config_path="/opt/${type_name}/config/${env}-${project_name}"
    if [[ ! -d ${data_path} ]];then
        mkdir -p ${data_path}
    fi
    docker_name=${env}-${type_name}-${project_name}
    docker_name=$(echo ${docker_name//\//_})
    docker inspect ${docker_name} > /dev/null
    if [[ $? -ne 0 ]];then
        if [[ ${type_name} == "redis" ]];then
            passwd_file=${data_path}/passwd
            if [[ ! -d ${data_path} ]];then
                passwd=$(head -c 16 /dev/urandom | od -An -t x | tr -d ' ')
                echo ${passwd} > ${passwd_file}
            fi
            echo "密码为：" ${passwd}
            if [[ -f ${passwd_file} ]];then
                passwd=$(cat ${passwd_file})
                docker run --name ${docker_name} --restart=always -p ${node_port}:6379 -v ${data_path}:/data  -d ${image_name} --requirepass "${passwd}" --appendonly yes
            else
                docker run --name ${docker_name} --restart=always -p ${node_port}:6379 -v ${data_path}:/data  -d ${image_name} --appendonly yes
            fi
            #docker run --name ${docker_name} --restart=always -p ${node_port}:6379 -v ${data_path}:/data  -d ${image_name} --appendonly yes
        elif [[ ${type_name} == "zookeeper" ]];then
            docker run --name ${docker_name} --restart=always -p ${node_port}:2181 -v ${data_path}:/data  -d ${image_name}
        elif [[ ${type_name} == "rabbitmq" ]];then
            docker run --name ${docker_name} --restart=always -p ${node_port}:5672 -p $(($node_port+1)):15672  -e RABBITMQ_DEFAULT_USER=admin -e RABBITMQ_DEFAULT_PASS=admin -d ${image_name}
        elif [[ ${type_name} == "kafka" ]];then
            jmx_port="9999"
            zk_port=$(cat ${container_list_file} | grep ${env} | grep zookeeper |awk '{print $NF}')
            docker run --name ${docker_name} --restart=always -p ${node_port}:9092 -e JMX_PORT=${jmx_port} -e KAFKA_ADVERTISED_HOST_NAME="${local_ip}" -e KAFKA_ZOOKEEPER_CONNECT="${local_ip}:${zk_port}" -e KAFKA_BROKER_ID="1" -e KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR="1" -e  KAFKA_ADVERTISED_LISTENERS="PLAINTEXT://${local_ip}:${node_port}" -e KAFKA_LISTENERS="PLAINTEXT://0.0.0.0:9092" -d ${image_name}
        elif [[ ${type_name} == "kafka-manager" ]];then
            zk_port=$(cat ${container_list_file} | grep ${env} | grep zookeeper |awk '{print $NF}')
            docker run --name ${docker_name} --restart=always -p ${node_port}:9000 -e ZK_HOSTS="${local_ip}:${zk_port}" -d ${image_name}
        elif [[ ${type_name} == "memcached" ]];then
            docker run --name ${docker_name} --restart=always -p ${node_port}:11211 -d ${image_name}
        elif [[ ${type_name} == "consul" ]];then
            docker run --name ${docker_name} --restart=always -p ${node_port}:8500 -v ${data_path}/data:/consul/data -v ${data_path}/config:/consul/config -h ${docker_name} -d consul:1.3 agent -server -bootstrap-expect=1  -node=${docker_name} -client 0.0.0.0 -ui
        elif [[ ${type_name} == "elasticsearch" ]];then
            docker run --name ${docker_name} --restart=always -p ${node_port}:9200 -p $(($node_port+100)):9300 -e ES_JAVA_OPTS="-Xms${es_memory} -Xmx${es_memory}" -v ${data_path}:/usr/share/elasticsearch/data  -v ${config_path}:/usr/share/elasticsearch/config -d ${image_name}
        elif [[ ${type_name} == "mongo" ]];then
            passwd_file=${data_path}/passwd
            if [[ ! -d ${data_path} ]];then
                if [[ -f ${passwd_file} ]];then
                    passwd=$(cat ${passwd_file})
                fi
            else
                passwd=$(head -c 16 /dev/urandom | od -An -t x | tr -d ' ')
                echo ${passwd} > ${passwd_file}
            fi
            echo "密码为：" ${passwd}
            docker run --name ${docker_name} --restart=always -p ${node_port}:27017 -v ${data_path}:/data/db  -d ${image_name} --auth
            #sleep 3
            #docker exec -i ${docker_name} mongo admin --eval "db.createUser({user: 'admin', pwd: '${passwd}', roles: [{role: 'root', db: 'admin'}]});"
        fi
    fi
done < ${container_list_file}
```

### 备注：请使用 dns 解析，不要直接使用 ip
