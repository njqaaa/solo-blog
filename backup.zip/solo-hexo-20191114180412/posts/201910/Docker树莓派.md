title: Docker - 树莓派
date: '2019-10-21 19:59:55'
updated: '2019-10-23 13:14:17'
tags: [Docker]
permalink: /articles/2019/10/21/1571659195708.html
---
### MySQL

```
docker run --name ${app_name} -d -p 3306:3306 -v /root/cloud/data/User/admin/home/mysql/my.cnf:/etc/mysql/my.cnf -v /root/cloud/data/User/admin/home/mysql:/var/lib/mysql -e MYSQL_ROOT_PASSWORD=TVlTUUxfUk9PVF9QQVNTV09SRA hypriot/rpi-mysql
```

### 可道云 私有云

```
docker run --restart=always -p 88:80 --name=${app_name} -d -v /root/cloud/data:/var/www/html/data -v /root/cloud/config:/var/www/html/config yangxuan8282/kodexplorer:arm
```

### Solo 博客

```
docker run --restart=always -d -p 8081:8080 --name=${app_name} --link mysql:mysql -v /etc/localtime:/etc/localtime -v /root/cloud/data/User/admin/home/solo/solo_h2:/root/solo_h2 -v /root/cloud/data/User/admin/home/solo/code:/usr/local/tomcat/webapps/ROOT arm32v7/tomcat:8-jre8-alpine
```

### gogs Git 仓库

```
docker run --restart=always -d -p 10022:22 -p 10080:3000 --name=${app_name} --link mysql:mysql -v /root/cloud/data/User/admin/home/gogs/:/data gogs/gogs-rpi:0.11.91
```

### aria2 下载

```
docker run -d --name aria2 -p 6800:6800 -p 6880:80 -p 6888:8080 -v /root/cloud/data/User/admin/home/downloads:/aria2/downloads -e SECRET=123456 yuukiyuuna/aria2-rpi
```

### wordpress

```
docker run --restart=always -d -p 99:80 --name=${app_name} --link mysql:mysql --env-file=$(cd `dirname $0`; pwd)/envfile -v /root/cloud/data/User/admin/home/wordpress/:/var/www/html arm32v7/wordpress:apache  
```
