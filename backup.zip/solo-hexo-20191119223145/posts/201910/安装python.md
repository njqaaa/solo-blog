title: 安装 - python
date: '2019-10-22 15:38:00'
updated: '2019-10-23 13:15:20'
tags: [安装部署]
permalink: /articles/2019/10/22/1571729880206.html
---
```
#!/bin/bash
yum install -y git openssl-devel python-devel gcc gcc-c++ libtool make mysql-devel MYSQL-python
cd /usr/local/src
wget https://www.python.org/ftp/python/3.6.8/Python-3.6.6.tgz
tar -xzvf Python-3.6.6.tgz
export PYTHON_TGZ_VERSION=3.6.6
export PYTHON_VERSION=3.6
cd Python-3.6.6
./configure --prefix=/usr/local/python-${PYTHON_VERSION} --enable-shared
make && make install
ln -sf /usr/local/python-${PYTHON_VERSION}/lib/libpython${PYTHON_VERSION}m.so.1.0 /usr/lib64/
ln -sf /usr/local/python-${PYTHON_VERSION}/lib/python${PYTHON_VERSION}/configparser.py /usr/local/python-${PYTHON_VERSION}/lib/python${PYTHON_VERSION}/ConfigParser.py
ln -sf /usr/local/python-${PYTHON_VERSION}/bin/pip3 /usr/local/bin/
ln -sf /usr/local/python-${PYTHON_VERSION}/bin/python3 /usr/local/bin/

/usr/local/bin/pip3 install --upgrade pip
/usr/local/bin/pip3 install gunicorn
ln -s /usr/local/python-3.6/bin/gunicorn /usr/local/bin/
```
