title: Prometheus - node-exporter指标
date: '2019-10-22 16:03:46'
updated: '2019-10-23 13:11:42'
tags: [Prometheus]
permalink: /articles/2019/10/22/1571731425979.html
---
* CPU
  * 收集 CPU 统计信息
* diskstats
  * 从/proc/diskstats 中收集磁盘 I/O 统计信息
* filefd
  * 从/proc/sys/fs/file-nr 中收集文件描述符统计信息
* filesystem
  * 文件系统统计信息，例如磁盘已使用空间
* loadavg
  * 收集系统负载信息
* meminfo
  * 内存统计信息
* netdev
  * 网口流量统计信息，单位 bytes
* netstat
  * 从/proc/net/netstat 收集网络统计数据，等同于 netstat -s
* sockstat
  * 从/proc/net/sockstat 中收集 socket 统计信息
* stat
  * 从/proc/stat 中收集各种统计信息，包含系统启动时间，forks,中断等
* time
  * 系统当前时间
* uname
  * 通过 uname 系统调用,获取系统信息
* vmstat
  * 从/proc/vmstat 中收集统计信息
* ksmd
  * 从/sys/kernel/mm/ksm 中获取内核和系统统计信息
* logind
  * 从 logind 中收集会话统计信息
* arp
  * 从/proc/net/arp 中收集 ARP 统计信息
* conntrack
  * 从/proc/sys/net/netfilter/中收集 conntrack 统计信息
* edac
  * 错误检测与纠正统计信息
* entropy
  * 可用内核熵信息
* hwmon
  * 从/sys/class/hwmon/中收集监控器或传感器数据信息
* infiniband
  * 从 InfiniBand 配置中收集网络统计信息
* mdadm
  * 从/proc/mdstat 中获取设备统计信息
* textfile
  * 通过--collector.textfile.directory 参数指定本地文本收集路径，收集文本信息
* wifi
  * 收集 wifi 设备相关统计数据
* xfs
  * 收集 xfs 运行时统计信息(kernel4.4+)
* zfs
  * 收集 zfs 性能统计信息
* bonding
  * 收集系统配置以及激活的绑定网卡数量
* buddyinfo
  * 从/proc/buddyinfo 中收集内存碎片统计信息
* drbd
  * 收集远程镜像块设备（DRBD）统计信息
* interrupts
  * 收集更具体的中断统计信息
* ipvs
  * 从/proc/net/ip_vs 中收集 IPVS 状态信息，从/proc/net/ip_vs_stats 获取统计信息
* meminfo_numa
  * 从/proc/meminfo_numa 中收集内存统计信息
* mountstats
  * 从/proc/self/mountstat 中收集文件系统统计信息，包括 NFS 客户端统计信息
* nfs
  * 从/proc/net/rpc/nfs 中收集 NFS 统计信息，等同于 nfsstat-c
* qdisc
  * 收集队列推定统计信息
* runit
  * 收集 runit 状态信息
* supervisord
  * 收集 supervisord 状态信息
* systemd
  * 从 systemd 中收集设备系统状态信息
* tcpstat
  * 从/proc/net/tcp 和/proc/net/tcp6 收集 TCP 连接状态信息
