title: 传统运维 - consul操作
date: '2019-10-28 17:08:37'
updated: '2019-10-28 17:11:24'
tags: [传统运维]
permalink: /articles/2019/10/28/1572253717120.html
---
### 查看 service id

```
curl ${CONSUL_CATALOG_API}/agent/services | jq .
```

### 注销 service

```
curl -X PUT -H 'application/json' ${CONSUL_CATALOG_API}/agent/service/deregister/${service_id}
```

### 注销 node
```
curl -X PUT -H 'application/json' -d '{"Datacenter": "dc1","Node": "'${ip}'"}' ${CONSUL_CATALOG_API}/deregister
```

### 注册 node
```
{
	"Datacenter": "dc1",
	"Node": "ali-hz-office-gitlabrunner-gitlabrunnerlinux-001",
	"Address": "10.111.115.218",
	"NodeMeta": {
		"dpt": "office",
		"group": "office-gitlabrunner",
		"hostname": "ali-hz-office-gitlabrunner-gitlabrunnerlinux-001"
	},
	"Service": {
		"ID": "server",
		"Service": "node_exporter",
		"Tags": [
			"primary",
			"v1"
		],
		"Address": "10.111.115.218",
		"Port": 9100
	},
	"SkipNodeUpdate": false
}

curl -s --request PUT --data @${temp_file} ${CONSUL_CATALOG_API}/register
```
