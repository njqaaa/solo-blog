title: Docker - 开启gpu
date: '2019-10-21 15:50:03'
updated: '2019-10-21 16:56:52'
tags: [Docker]
permalink: /articles/2019/10/21/1571644203097.html
---

```
lspci | grep NVIDIA
```

### 资料
[nvidia-docker](https://github.com/NVIDIA/nvidia-docker)

[cuda下载](https://developer.nvidia.com/cuda-downloads?target_os=Linux&target_arch=x86_64&target_distro=CentOS&target_version=7&target_type=rpmlocal)

[cudnn下载](https://developer.nvidia.com/rdp/cudnn-archive)

[启用Docker虚拟机GPU，加速深度学习](https://blog.csdn.net/mogoweb/article/details/80633235)

[测试gpu效果](https://databricks.com/tensorflow/using-a-gpu)

[镜像源](https://nvidia.github.io/nvidia-docker/)
### /etc/docker/daemon.json
```
{
    "registry-mirrors": ["http://f1361db2.m.daocloud.io"],
    "runtimes": {
        "nvidia": {
            "path": "nvidia-container-runtime",
            "runtimeArgs": []
        }
    }
}
```
```
docker run -it --runtime=nvidia --rm nvidia/cuda:9.0-base nvidia-smi
```
