title: Ldap - jumpserver
date: '2019-10-22 13:16:14'
updated: '2019-10-22 13:16:14'
tags: [Ldap]
permalink: /articles/2019/10/22/1571721374525.html
---
![image.png](https://img.hacpai.com/file/2019/10/image-2d94aa78.png)

