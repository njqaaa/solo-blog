title: Ansible - 相关配置
date: '2019-10-29 15:30:23'
updated: '2019-10-29 15:30:41'
tags: [Ansible]
permalink: /articles/2019/10/29/1572334223617.html
---
### ~/.ansible.cfg

```
[defaults]
private_key_file = ~/.ssh/id_dsa
remote_user = dev
remote_tmp     = /tmp/jenkins/.ansible/tmp
retry_files_save_path = ~/.ansible-retry
command_warnings = False
ssh_args = -o ControlMaster=auto -o ControlPersist=5d
```

### /etc/ansible.cfg

```
[defaults]
forks          = 20
remote_port    = 16300
host_key_checking = False
remote_user = dev
private_key_file = /home/dev/.ssh/ansible
system_warnings = False
deprecation_warnings = False
command_warnings = False
retry_files_save_path = ~/.ansible-retry
[privilege_escalation]
[paramiko_connection]
[ssh_connection]
ssh_args = -C -o ControlMaster=auto -o ControlPersist=60s
[persistent_connection]
connect_timeout = 30
connect_retries = 30
connect_interval = 1
```
