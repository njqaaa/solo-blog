title: Kubernetes - helm
date: '2019-10-21 07:54:14'
updated: '2019-10-21 08:57:09'
tags: [Kubernetes]
permalink: /articles/2019/10/21/1571644454171.html
---
### 仓库
```
fabric8      	https://fabric8.io/helm
stable       	https://apphub.aliyuncs.com
bitnami      	https://charts.bitnami.com/bitnami
aliyun-stable	https://acs-k8s-ingress.oss-cn-hangzhou.aliyuncs.com/charts
google       	https://kubernetes-charts.storage.googleapis.com/
c7n          	https://openchart.choerodon.com.cn/choerodon/c7n/	https://helm.github.io/monocular
chartmuseum	http://127.0.0.1:8080
apphub	https://apphub.aliyuncs.com
```

### 安装
```
helm install traefik stable/traefik --set replicas=1
```

### 升级
```
helm upgrade traefik stable/traefik  -f <(helm get values traefik) --set externalTrafficPolicy=Local,ssl.enforced=false
```
