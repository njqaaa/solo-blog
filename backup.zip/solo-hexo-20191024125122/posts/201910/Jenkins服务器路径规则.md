title: Jenkins - 服务器路径规则
date: '2019-10-23 16:03:31'
updated: '2019-10-23 16:03:31'
tags: [Jenkins]
permalink: /articles/2019/10/23/1571817811388.html
---
* node 部署方式

  * 代码路径：/opt/static/${group}/${project}
* 其他部署方式

  * 代码路径：/opt/case/${group}/${project}
  * 日志路径：/opt/logs/${app_deploy_type}/${group}/${project}
* 假设仓库为：https://${gitlab_domain}/study/xue.gateway.learn
* 部署方式为 Jetty

  * 代码路径为：/opt/case/study/xue.gateway.learn
  * 日志路径为： /opt/logs/jetty/study/xue.gateway.learn
