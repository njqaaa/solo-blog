title: 'PHP - BOM( \ufeff )处理 '
date: '2019-10-23 23:02:54'
updated: '2019-10-24 13:49:54'
tags: [PHP]
permalink: /articles/2019/10/23/1571842974386.html
---
### 方法一（堵漏法）

#### 既然在 json_encode()中传入了带 BOM 格式的 UTF-8 数据，导致了问题，那么我们可以在传入参数前，对参数进行一下过滤，也就是移除参数中的 BOM，PHP 代码如下：

```
$result = trim($result, "\xEF\xBB\xBF");
```

### 方法二（治本法）

#### 导致问题的根本原因是项目中存在带 BOM 格式的 UTF-8 文件，那么要从根本上解决问题就必须将带 BOM 格式文件转换成无 BOM 格式文件，在 Linux 下可以通过下面两条命令查找带 BOM 格式文件和将文件转换成无 BOM 格式：

#### 在项目根目录，查找项目中带 BOM 格式文件并显示

```
grep -r -I -l $'^\xEF\xBB\xBF' ./
```

#### 在项目根目录下，将目录下所有文件去除 BOM 头（注意：不能对图片进行此操作，否则会导致图片打不开）

```
find . -type f -exec sed -i 's/\xEF\xBB\xBF//' {} \;
```
