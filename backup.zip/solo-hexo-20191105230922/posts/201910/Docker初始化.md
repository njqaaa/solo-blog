title: Docker - 初始化
date: '2019-10-25 19:18:38'
updated: '2019-10-25 19:23:31'
tags: [Docker]
permalink: /articles/2019/10/25/1572002318110.html
---
### [升级内核](http://www.elrepo.org/)

```
uname -r
rpm --import https://www.elrepo.org/RPM-GPG-KEY-elrepo.org
rpm -Uvh https://www.elrepo.org/elrepo-release-7.0-3.el7.elrepo.noarch.rpm
yum --enablerepo=elrepo-kernel install -y  kernel-ml-devel kernel-ml
grub2-set-default 0
reboot
uname -r
```

### 安装 Docker

```
yum install -y yum-utils
yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
yum makecache fast
yum install -y docker-ce
systemctl restart docker
systemctl enable docker.service
```

### 加速

```
curl -sSL https://get.daocloud.io/daotools/set_mirror.sh | sh -s http://xxxx.m.daocloud.io
```

### 设置 IP 段(/etc/docker/daemon.json)

```
{
"bip":"192.168.100.1/24"
}
```

### 修改 Docker 存储路径(/etc/docker/daemon.json)

```
{
"graph": "/opt/docker"
}
```

### 设置容器代理(/usr/lib/systemd/system/docker.service)

```
[Service]
Environment="HTTP_PROXY=http://10.53.xx.xx:1080/"
```
