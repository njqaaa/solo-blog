title: Java - jetty配置
date: '2019-10-21 17:36:55'
updated: '2019-10-24 13:49:07'
tags: [Java]
permalink: /articles/2019/10/21/1571650615821.html
---
### bin/jetty.sh

```
-    "$JETTY_SH" stop "$@"
+    "$JETTY_SH" stop -force "$@"
```

### etc/jetty-requestlog.xml

```
-      <Set name="LogTimeZone"><Property name="jetty.requestlog.timezone" deprecated="requestlog.timezone" default="GMT"/></Set>
+      <Set name="LogTimeZone"><Property name="jetty.requestlog.timezone" deprecated="requestlog.timezone" default="Asia/Shanghai"/></Set>
```

### etc/jetty.conf

```
+jetty-logging.xml
```

### etc/jetty.xml

```
-      <Set name="maxThreads" type="int"><Property name="jetty.threadPool.maxThreads" deprecated="threads.max" default="200"/></Set>
+      <Set name="maxThreads" type="int"><Property name="jetty.threadPool.maxThreads" deprecated="threads.max" default="1000"/></Set>
+    <Call name="setAttribute">
+      <Arg>org.eclipse.jetty.server.Request.maxFormContentSize</Arg>
+      <Arg>-1</Arg>
+    </Call>
+    <Call name="setAttribute">
+      <Arg>org.eclipse.jetty.server.Request.maxFormKeys</Arg>
+      <Arg>-1</Arg>
+    </Call>
+
     <Set name="stopAtShutdown"><Property name="jetty.server.stopAtShutdown" default="true"/></Set>
     <Set name="stopTimeout"><Property name="jetty.server.stopTimeout" default="5000"/></Set>
     <Set name="dumpAfterStart"><Property name="jetty.server.dumpAfterStart" deprecated="jetty.dump.start" default="false"/></Set>
     <Set name="dumpBeforeStop"><Property name="jetty.server.dumpBeforeStop" deprecated="jetty.dump.stop" default="false"/></Set>

+    <Call name="insertHandler">
+      <Arg>
+        <New id="RequestLog" class="org.eclipse.jetty.server.handler.RequestLogHandler">
+          <Set name="requestLog">
+            <New id="RequestLogImpl" class="org.eclipse.jetty.server.NCSARequestLog">
+              <Set name="filename"><Property name="jetty.logs" default="./logs"/>/yyyy_mm_dd.request.log</Set>
+              <Set name="filenameDateFormat">yyyy_MM_dd</Set>
+              <Set name="LogTimeZone">Asia/Shanghai</Set>
+              <Set name="retainDays">7</Set>
+              <Set name="append">true</Set>
+              <Set name="LogLatency">true</Set>
+            </New>
+          </Set>
+        </New>
+      </Arg>
+    </Call>
```

### start.ini

```
-# jetty.http.port=8080
+jetty.http.port=8080
```
