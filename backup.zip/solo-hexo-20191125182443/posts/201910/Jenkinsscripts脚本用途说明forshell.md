title: Jenkins - scripts脚本用途说明for shell
date: '2019-10-24 15:13:01'
updated: '2019-10-24 18:37:16'
tags: [Jenkins]
permalink: /articles/2019/10/24/1571901180981.html
---
* check-build.sh

  * 验证是否需要 build，为 dev 环境构建所需（多分支并存）
* common.sh

  * 注意：脚本自身变量使用小写
  * 生成其他脚本所需变量，列表如下
    * app_env
    * app_name
    * backup_path
    * branch_name
    * config_dir_name
    * config_path
    * exclude_name
    * gitcommit_file
    * gitlog_file
    * hfjy_gopath
    * hosts_file
    * java_job_name
    * job_name
    * job_path
    * job_url
    * local_path
    * mapping_file
    * msg_path
    * project_name
    * project_path
    * reg
    * reg_env
    * region_mapping_file
    * release_history_version_file
    * release_version_file
    * remote_hosts
    * remote_path
    * target_path
    * use_gitlab
    * version_file
* function-common.sh

  * 公共方法，被其他脚本所引入
* function-java.sh

  * 仅适用于 Java 的公共方法
* function-php.sh

  * 仅适用于 Java 的公共方法
* git.sh

  * Git 相关操作
* go.sh | java.sh | node.sh | npm.sh

  * 代码语言相关
* push-config-jenkins.sh

  * 已废弃
* `` release-${app_deploy_type}.sh ``

  * 根据部署类型命名
    * `` 与 release-${app_deploy_type}.yaml `` 配合使用
  * 例如语言为 Java，则部署类型有
    * Jetty
    * SpringBoot
    * Tomcat
* restart-service.yaml

  * 已废弃
* send-dingding-ops.sh

  * 已废弃？好像迁移至 ops 目录下了
* send-dingding.sh

  * 发布后钉钉群通知
* under-line.sh

  * 已废弃
* update-config.sh

  * 更新生产 job 可以发布的版本号
