title: Kubernetes - 资料
date: '2019-10-21 17:01:03'
updated: '2019-10-23 13:12:29'
tags: [Kubernetes]
permalink: /articles/2019/10/21/1571648463572.html
---
[docker相关分享](http://dockerone.com/)

[亲和性和反亲和性](https://www.jianshu.com/p/61725f179223)
