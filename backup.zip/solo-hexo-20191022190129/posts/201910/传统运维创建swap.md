title: 传统运维 - 创建swap
date: '2019-10-21 17:10:22'
updated: '2019-10-21 17:10:22'
tags: [传统运维]
permalink: /articles/2019/10/21/1571649022625.html
---
### 创建要作为swap分区,其中的count等于想要的块的数量（bs*count=文件大小）。
```
dd if=/dev/zero of=/root/swapfile bs=1M count=1024
```
### 变更权限
```
chmod 600 /root/swapfile
```

### 格式化为交换分区文件
```
mkswap /root/swapfile #建立swap的文件系统
```

### 启用交换分区文件:
```
swapon /root/swapfile #启用swap文件
```
