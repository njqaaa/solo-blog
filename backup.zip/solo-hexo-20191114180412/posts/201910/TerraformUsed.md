title: Terraform - Used
date: '2019-10-21 17:09:34'
updated: '2019-10-23 13:16:56'
tags: [Terraform]
permalink: /articles/2019/10/21/1571648974851.html
---
### 仓库

[github](https://github.com/njqaaa/terraform-for-cloud)

### 使用变量文件

```
terraform apply -var-file=variables/dns/hfjy123_com.tfvars -target=module.dns-hfjy123_com
```

### 阿里云

```
export ALICLOUD_ACCESS_KEY=xxx
export ALICLOUD_SECRET_KEY=yyy
export ALICLOUD_REGION=cn-hangzhou
export ALICLOUD_ACCOUNT_SITE=Domestic
export outfile=gotest.out
```
