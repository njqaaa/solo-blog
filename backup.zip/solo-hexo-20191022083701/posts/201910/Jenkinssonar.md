title: Jenkins - sonar
date: '2019-10-21 08:51:49'
updated: '2019-10-21 08:51:49'
tags: [Jenkins]
permalink: /articles/2019/10/21/1571647908917.html
---
### Exclute shell
```
branch=$(echo $GIT_BRANCH | awk -F '/' '{print $NF}')
if [[ -d "target" ]];then
    target_path="target"
else
    target_path=$( find . -name target | grep "server/" |awk -F '\\./' '{print $2}')    
fi
if [[ ${JOB_NAME} =~ "/" ]];then
    job_name=$(echo ${JOB_NAME} | awk -F '/' '{print $2}')
else
    job_name=${JOB_NAME}
fi
echo "sonar.projectKey=${job_name}
sonar.projectName=${job_name}
sonar.sources=${WORKSPACE}
sonar.branch=${branch}
sonar.java.binaries=${target_path}/classes">> .sona
```

### Exclute SonarQube Scanner 插件
```
${WORKSPACE}/.sona

sonar.login=jenkins
sonar.password=jenkinspasswd
```
