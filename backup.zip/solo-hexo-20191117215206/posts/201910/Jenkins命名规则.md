title: Jenkins - 命名规则
date: '2019-10-23 16:03:31'
updated: '2019-10-30 16:56:27'
tags: [Jenkins]
permalink: /articles/2019/10/23/1571817811388.html
---
* 采用 GitLab 的 group 与 project
* 假设仓库为：`` https://${gitlab_domain}/study/xue.gateway.learn ``，则 group=study，project=xue.gateway.learn
* 此规则适用以下情况
  * Jenkins ui
    * `` ${group}-${env}/${project} ``
    * env 可选值
      * dev
      * test
      * offline
      * offline-sj
      * sj
      * online
  * ansible Inventory
    * `` ${group}-${project} ``
  * 代码路径
    * node 部署方式
      * `` /opt/static/${group}/${project} ``
  * 其他部署方式
    * `` /opt/case/${group}/${project} ``
  * 日志路径
    * `` /opt/logs/${app_deploy_type}/${group}/${project} ``
    * app_deploy_type 为部署方式
* nginx upstream
  * upstream name： `` ${group}-${project} ``
* consul kv
  * `` ${group}-${project} ``
* 阿里云 sls
  * `` hf-${group}/${project} ``
