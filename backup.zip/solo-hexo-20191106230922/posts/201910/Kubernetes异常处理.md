title: Kubernetes - 异常处理
date: '2019-10-21 16:59:06'
updated: '2019-10-23 13:12:43'
tags: [Kubernetes]
permalink: /articles/2019/10/21/1571648346180.html
---
### 强制删除状态 ternamtied 的 pod

```
kubectl delete pod test-6cf9c4dc9b-g2fj8 --grace-period=0 --force
```
