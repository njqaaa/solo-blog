title: 安装 - consul集群
date: '2019-10-22 07:39:11'
updated: '2019-10-22 07:39:11'
tags: [安装部署]
permalink: /articles/2019/10/22/1571729951539.html
---
### [部署参考](https://kingfree.gitbook.io/consul/day-1-operations/deployment-guide)

### 下载并移动consul
```
cd /usr/local/src && wget http://soft.ops.hfjy.com/other/consul_1.4.4_linux_amd64.zip && unzip consul_1.4.4_linux_amd64.zip && mv consul /usr/local/bin
```

### 命令补全
```
consul -autocomplete-install
complete -C /usr/local/bin/consul consul
```

### 创建目录并授权
```
mkdir /etc/consul.d  && chown dev:dev -R /etc/consul.d
mkdir /opt/consul && chown dev:dev -R /etc/consul.d
```

### /etc/consul.d/consul.hcl
```
datacenter = "dc1"
data_dir = "/opt/consul"
encrypt = "Luj2FZWwlt8475wD1WtwUQ=="
retry_join = ["consul-1.hfjy.com","consul-2.hfjy.com","consul-3.hfjy.com"]
performance {
raft_multiplier = 1
}
```

### /etc/consul.d/server.hcl
```
server = true
bootstrap_expect = 3
ui = true
```

### /etc/systemd/system/consul.service
```
[Unit]
Description="HashiCorp Consul - A service mesh solution"
Documentation=https://www.consul.io/
Requires=network-online.target
After=network-online.target
ConditionFileNotEmpty=/etc/consul.d/consul.hcl

[Service]
User=dev
Group=dev
ExecStart=/usr/local/bin/consul agent -config-dir=/etc/consul.d/ -bind=0.0.0.0 -client=0.0.0.0
ExecReload=/usr/local/bin/consul reload
KillMode=process
Restart=on-failure
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
```

### 设置开机自启
```
systemctl enable consul && systemctl restart consul
```
