title: Jenkins - 自定义功能
date: '2019-10-29 15:59:07'
updated: '2019-10-29 16:04:39'
tags: [Jenkins]
permalink: /articles/2019/10/29/1572335947879.html
---
* 采用pipeline + shell模式，极大的降低了变更pipeline频率。
* 备份Jenkins代码至oss，排除无非部分的目录。
* 定时清理历史workspace。
* 定时删除gitlab上每个仓库，最后一条commit大与N天的分支。
* docker方式编译代码。
* 自定义+默认 编译命令。
* test环境备份编译后代码（用于预发布、生产环境等）
* test环境备份后，push对应的tag号至对应的生产job。
* 每个部署方式都有对应的``release-${app_deploy_type}.sh`` ``release-${app_deploy_type}.yaml``，方便扩展。
* 每个语言都有对应的``${lang}.sh``，用于编译命令。

* 远程服务器代码根目录下生成.version文件
```
19.10.091
Merge branch 'feature-201910-08-xxy' into 'master' (2019-10-08 08:01:36 +0000) <zhazhahui>
2019-10-09 16:02:45 online
```
* 发布完成后，调用api修改Jenkins log信息
```
![image.png](https://img.hacpai.com/file/2019/10/image-352f9940.png)
```

* 发布完成后钉钉消息通知 （使用shell + api实现），如发布失败，MESSAGE会显示详情。
```  
发布时间：2019-10-09 16:02:45  
# JOB_NAME：study/xue.gateway.api   
# DESC：负责每晚或者定时跑的job,发红包,发短信相关接口   
# ENV：online   
# STATUS：SUCCESS   
# 部署方式：jetty   
# TAG_VERSION：19.10.091   
# BUILD_USER：张三  
# 发布描述：这个人很懒，什么都没留下。   
# MESSAGE：本次发布成功  
```
