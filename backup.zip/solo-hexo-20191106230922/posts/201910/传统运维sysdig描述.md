title: 传统运维 - sysdig描述
date: '2019-10-22 15:42:28'
updated: '2019-10-24 18:39:11'
tags: [传统运维]
permalink: /articles/2019/10/22/1571730148811.html
---
### [sysdig](https://github.com/draios/sysdig)

- 是一个容器排错工具，它可以捕获系统调用和来自于 Linux 内核的事件。
- Sysdig 就是 strace + tcpdump + htop + iftop + lsof + wireshark。
- Sysdig 在物理机和虚拟机的操作系统级别使用。
- 通过安装进 Linux 内核，捕获系统调用和其他操作系统事件。
- Sysdig 也可以为系统活动创建 trace 文件。
- 安装参考：[https://www.ibm.com/developerworks/cn/linux/1607_caoyq_sysdig/index.html](https://www.ibm.com/developerworks/cn/linux/1607_caoyq_sysdig/index.html)
