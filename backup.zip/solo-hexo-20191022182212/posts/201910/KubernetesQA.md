title: Kubernetes - Q&A
date: '2019-10-21 17:03:16'
updated: '2019-10-22 15:47:16'
tags: [Kubernetes]
permalink: /articles/2019/10/21/1571648595895.html
---
### Q：同一个应用的多个pod调度至同一个node节点，当节点不可用，则应用无法提供服务。
### A：podAntiAffinity 。[亲和性和反亲和性](https://www.jianshu.com/p/61725f179223)
