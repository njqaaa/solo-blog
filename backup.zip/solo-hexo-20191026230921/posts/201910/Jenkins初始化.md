title: Jenkins - 初始化
date: '2019-10-25 20:05:22'
updated: '2019-10-25 20:05:22'
tags: [Jenkins]
permalink: /articles/2019/10/25/1572005122202.html
---
### 安装Jenkins

```
wget -O /etc/yum.repos.d/jenkins.repo http://jenkins-ci.org/redhat/jenkins.repo
rpm --import http://pkg.jenkins-ci.org/redhat/jenkins-ci.org.key
yum install jenkins -y
```

### 配置环境变量(/etc/profile.d/jenkins.sh)

```
JAVA_HOME=/usr/local/java
JRE_HOME=${JAVA_HOME}/jre
CLASS_PATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar:$JRE_HOME/lib
PATH=$PATH:$JAVA_HOME/bin:$JRE_HOME/bin
export JAVA_HOME JRE_HOME CLASS_PATH PATH
```

#### 修配置文件(/etc/sysconfig/jenkins)

```
JENKINS_HOME="/opt/app/jenkins"
JENKINS_USER="dev"
JENKINS_PORT="8080"
```

#### 创建项目存放目录,并给日志目录和缓存目录赋权

```
mkdir -p ${JENKINS_HOME}
chown ${JENKINS_USER}:${JENKINS_USER}-R /opt/app/jenkins
chown ${JENKINS_USER}:${JENKINS_USER} -R /var/log/jenkins
chown  ${JENKINS_USER}:${JENKINS_USER} -R  /var/cache/jenkins
```

#### 启动服务

```
systemctl start jenkins
systemctl enable jenkins
```

### 复制密码粘贴访问

```
cat ${JENKINS_HOME}/secrets/initialAdminPassword
```

#### 常用插件

```
首先安装默认插件，然后安装以下插件
Ant #ant是基于java的一款构建工具，通过配置build.xml，让项目可以进行编译、部署、打包。因为我们要实现自动构建，所以首先要安装ant,一般不需要安装
Autofavorite for Blue Ocean #Blue Ocean自动收藏夹插件
Active Choices #通过自动获取git工程所有的分支，进行选择。可参考https://blog.csdn.net/jay763836801/article/details/52648530
Authorize Project #授权项目插件,参考文档https://wiki.jenkins.io/display/JENKINS/Authorize+Project+plugin
Badge #徽章插件可从管道中添加徽章并构建摘要条目。
Build Timestamp #使得job log的每次输出前面都增加当时的时间，方便查找job里脚本语句运行的间隔时间，方便查找问题。
Build Monitor View #一个独特的View， 可以将指定的Job,显示出来,当Job很多时，效果很好看
Build failure analyzer #按照预定的build failure 去解析console ouput, 然后高亮显示出来。方便定位出错位置，原因。

bouncycastle API #适用于Java和C＃的轻量级加密API
Branch API #该插件为多个基于分支的项目提供API
Blue Ocean #其目的就是让程序员执行任务时，降低工作流程的复杂度和提升工作流程的清晰度，它具有如下特征：清晰的可视化，对CI/CD pipelines, 可以快速直观的观察项目pipeline状态。pipeline精确度，通过UI直接介入pipeline的中间问题。
blueocean-core-js #就是在Jenkins套一层壳（蓝色背景）

Blue Ocean Pipeline Editor #参考https://www.58jb.com/html/183.html 用于在Blue Ocean用户界面中创建和编辑管道作业。
Build Name and Description Setter #可以通过变量显示构建编号-项目名称-环境-构建人等构建出来的工作流名称,可参考http://www.bubuko.com/infodetail-1680807.html

Configuration Slicing #支持单选复选多个job
Command Agent Launcher #命令代理启动器插件,允许代理使用指定的命令
Common API for Blue Ocean #Blue Ocean UI的一部分，通用api
Config API for Blue Ocean #Blue Ocean分析工具,配置api
Config File Provider #此插件允许直接在Jenkins UI中管理不同的文件类型。例如maven设置（settings.xml）或简单的文本文件这些文件可以在执行期间在作业中使用/引用
Credentials #凭证插件,允许jenkins中保存凭证
Credentials Binding #Jenkins凭证绑定插件,允许将凭据绑定到环境变量，以便从其他构建步骤中使用

Copy project link #复制项目链接插件此插件将“复制项目”链接添加到主项目页面的左侧面板中，以便于复制作业配置。
description setter #为jenkins的每个build设置description，可参考https://blog.csdn.net/hp_truth/article/details/46454063
Dingding[钉钉] #钉钉通知插件
Dashboard for Blue Ocean #Blue Ocean面板
Design Language #Jenkins Blue Ocean 插件的父POM项目
Display URL API #显示网址API,提供DisplayURLProvider扩展点，以提供在通知中使用的备用url
Display URL for Blue Ocean #这个插件为显示URL插件生成特定于BlueOcean的URL
Docker Commons #API插件，为各种与Docker相关的插件提供通用的共享功能
Docker Pipeline #Docker构建使用的流水线
Durable Task #为可以在Jenkins之外运行的进程提供扩展点的库
disk-usage #jenkins磁盘管理插件disk-usage plugin
Dynamic Extended Choice Parameter #动态选择分支插件，可参考https://blog.csdn.net/qq_20641565/article/details/79132797
Extended Choice Parameter #参数化构建过程（添加多选框）,可以参考https://blog.csdn.net/e295166319/article/details/54017231
Email Extension #这个插件是一个替代詹金斯的电子邮件出版商。它允许配置电子邮件通知的各个方面:何时发送电子邮件，谁应该接收它，以及电子邮件说了什么
Events API for Blue Ocean #Blue Ocean事件API
Folders #这个插件允许用户创建“文件夹”来组织作业。用户可以定义自定义分类法(如项目类型、组织类型等)。文件夹是可嵌套的，您可以在文件夹中定义视图
Git #这个插件集成了Git
Git client #在Jenkins中支持Git的实用插件
Git Pipeline for Blue Ocean #Blue Ocean Git单片机流水线创建
GIT server #该插件包装了JGit的服务器端功能，因此其他插件可以通过SSH传输和HTTP以协作方式轻松地从Jenkins公开Git存储库。从某种意义上说，该插件本身没有任何用户可见的功能，因此它是一个库插件
GitHub #集成了github仓库使用
GitHub API #可以使用github的api
GitHub Branch Source #来自GitHub的多分支项目和组织文件夹
GitHub Pipeline for Blue Ocean #BlueOcean GitHub组织流水线创建者
GitLab #这个插件允许GitLab触发Jenkins构建并在GitLab UI中显示结果。
Gradle #该插件为Jenkins 添加了Gradle支持。 Gradle作为Jenkins内部的另一个工具进行管理（与Ant或Maven相同），包括对自动安装的支持，并提供了一个新的构建步骤来执行Gradle任务
Handy Uri Templates 2.x API #Bundles Handy Uri 模版
HTML Publisher #这个插件发布HTML报告
i18n for Blue Ocean #Blue Ocean国际化(i18n)插件
Gitlab Hook Plugin #使用gitlab webhook实现自动化部署.可参考http://blog.51cto.com/bobbie/1913708
Git Parameter #动态选择分支插件，可参考https://blog.csdn.net/qq_20641565/article/details/79132797
Groovy #Groovy脚本语言
Groovy Postbuild #获得jenkins中系统的环境变量上传下构建的结果，可以参考https://blog.csdn.net/gzh8579/article/details/59522469
Jackson 2 API #该插件将FasterXML Jackson 2 API 暴露给Jenkins插件
Javadoc
JIRA #整合JIRA
JIRA Integration for Blue Ocean #Blue Ocean整合JIRA
Job Configuration History #保存所有作业和系统配置的副本
jQuery #这个插件提供一个标准版本的jQuery Javascript库
JSch dependency #将JSch库作为插件依赖项
JUnit #JUnit测试报告
JWT for Blue Ocean #启用基于JWT的BlueOcean API认证
Kubernetes Credentials #Kubernetes凭证插件
Locale #这个插件控制Jenkins的语言,通常，如果首选语言的翻译可用，Jenkins会尊重浏览器的语言首选项，并在构建过程中使用系统默认语言环境来显示消息。
Lockable Resources #Jenkins可锁定资源插件,该插件允许定义可被构建使用的可锁定资源（例如打印机，电话，计算机等）。如果构建需要已被锁定的资源，它将等待资源释放
Mailer #该插件可让您配置有关构建结果的电子邮件通知
Matrix Authorization Strategy #矩阵授权策略插件
Matrix Project #多配置(矩阵)项目类型
Maven Integration #整合Maven
Mercurial #该插件将Mercurial版本控制系统与Jenkins集成在一起。
Oracle Java SE Development Kit Installer #该插件提供了一个工具安装程序，用于在Jenkins中安装Oracle Java SE Development Kit
OWASP Markup Formatter #此插件根据OWASP AntiSamy MySpace清理策略清理HTML源，以 允许在用户提交的文本中使用有限的HTML标记。它还可以防止发出一些敏感的Jenkins UR
PAM Authentication #支持unix身份验证
Personalization for Blue Ocean #Blue Ocean个性化
Pipeline Graph Analysis #提供一个REST API来访问管道和管道运行数据
Pipeline implementation for Blue Ocean
Pipeline SCM API for Blue Ocean
Pipeline: API #定义管道API的插件
Pipeline: Basic Steps #管道中常用的步骤
Pipeline: Declarative #用于定义管道的类似于配置的语法
Pipeline: Declarative Extension Points API #用于声明管道中的扩展点的api。
Pipeline: Groovy

NodeJS #nodejs插件
Publish Over SSH #通过ssh构建推送
user build vars #设置构建用户名称变量
```
