title: Ldap - gitlab
date: '2019-10-22 13:16:58'
updated: '2019-10-22 13:16:58'
tags: [Ldap]
permalink: /articles/2019/10/22/1571721418459.html
---
![image.png](https://img.hacpai.com/file/2019/10/image-c65fb22e.png)

