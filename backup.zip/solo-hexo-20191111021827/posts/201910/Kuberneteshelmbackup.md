title: Kubernetes - helm backup
date: '2019-10-23 14:34:36'
updated: '2019-10-23 14:38:44'
tags: [Kubernetes]
permalink: /articles/2019/10/23/1571812476296.html
---
### 安装

```
helm plugin install [https://github.com/maorfr/helm-backup](https://github.com/maorfr/helm-backup)
```

### 使用

```
helm backup [flags] NAMESPACE

helm backup [flags] NAMESPACE --restore
```
