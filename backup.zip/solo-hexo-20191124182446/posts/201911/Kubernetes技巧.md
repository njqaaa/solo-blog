title: Kubernetes - 技巧
date: '2019-11-20 02:21:16'
updated: '2019-11-20 02:21:16'
tags: [Kubernetes]
permalink: /articles/2019/11/20/1574187676089.html
---
### 查看说明文档
```
kubectl explain Pods.metadata
```

### 生成当前pod模板
```
kubectl get pods -o yaml --export
```
