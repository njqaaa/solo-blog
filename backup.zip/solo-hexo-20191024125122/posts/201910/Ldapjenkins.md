title: Ldap - jenkins
date: '2019-10-22 13:17:29'
updated: '2019-10-22 13:17:29'
tags: [Ldap]
permalink: /articles/2019/10/22/1571721449166.html
---
![image.png](https://img.hacpai.com/file/2019/10/image-83ced254.png)

