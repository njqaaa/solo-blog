title: Kubernetes - 工具
date: '2019-10-21 17:01:35'
updated: '2019-10-21 17:01:35'
tags: [Kubernetes]
permalink: /articles/2019/10/21/1571648494965.html
---
### [kube-debug](https://github.com/aylei/kubectl-debug)
- 一个简单的 kubectl 插件, 能够帮助你便捷地进行 Kubernetes 上的 Pod 排障诊断.
- 背后做的事情很简单: 在运行中的 Pod 上额外起一个新容器, 并将新容器加入到目标容器的 pid, network, user 以及 ipc namespace 中, 这时我们就可以在新容器中直接用 netstat, tcpdump 这些熟悉的工具来解决问题了,
- 旧容器可以保持最小化, 不需要预装任何额外的排障工具.

### [kubectx](https://github.com/ahmetb/kubectx)
- 一款小型开源实用工具，其不仅能够增强Kubectl的功能表现，还能够轻松切背景，并同时与多个Kubernetes集群实现连接。
- Kubens允许用户在Kubernetes命名空间之间进行导航。
- 这两款工具均可在bash/zsh/fishshell上提供自动补全功能。

### [kubetail](https://github.com/johanhaleby/kubetail)
- 一个小型bash脚本，其能够将来自于多个pod的日志聚合到同一数据流中。
- 可使用multitail工具以构建日志并进行色彩填充。

### [kube-prompt](https://github.com/c-bata/kube-prompt)
- 一种带自动补全功能的kubernetes客户端，执行kube-prompt后进入一个shell。
- 在这里面不用kubectl，直接跟后面的命令并且可以自动补全。并且kubens执行后在这里面也是生效的。

### [kube-shell](https://github.com/cloudnativelabs/kube-shell)
- 能够在运行Kubectl时提升生产力。
- 能够启用命令以实施自动补全与自动建议。此外，Kube-shell还能够提供有关执行命令的内嵌文档，其甚至还可以在输入错误时执行检索与纠正命令。
- 一款能够在Kubernetes控制台中改进性能与生产力的工具。

### [k9s，正在迭代。。。](https://github.com/derailed/k9s)
- 一款基于终端的UI，会以特定时间间隔（默认为2秒）监控Kubernetes资源，并允许我查看自己集群中的内容。
- 可以使用ctx<enter>命令在开发集群与生产集群之间快速导航。
- 这款CLI还允许我按照命名空间进行过滤操作，并对大部分Kubernetes资源执行只读操作（这项功能仍在开发当中……）。
- 如果集群卡住，可以使用?<enter>命令列出所有受支持的资源。

### [kompose](https://github.com/kubernetes/kompose)
- 能够自动把 Docker Compose 应用转换为 Kubernetes 描述文件
- 可能存在误差，无人为介入判断

### [kubewatch](https://github.com/bitnami-labs/kubewatch)
- 一款Kubernetes监控工具，该产品可将Kubernetes事件发布到团队通信应用程序，即Slack。
- 以Kubernetes集群内部pod的形式运行，借此监视相关系统中所发生的各种变化。
- 您可以通过编辑配置文件来指定需要接收的通知。

---
### [kubeapps](https://github.com/kubeapps/kubeapps)
- helm市场

### [monocular](https://github.com/helm/monocular)
- Helm市场

### [chartmuseum](https://github.com/helm/chartmuseum)
- Helm Chart Repository

### [helm-backup](https://github.com/maorfr/helm-backup)
- 针对namespace的备份/还原

