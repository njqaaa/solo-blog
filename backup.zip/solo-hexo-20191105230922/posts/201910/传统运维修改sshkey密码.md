title: 传统运维 - 修改ssh key密码
date: '2019-10-21 17:11:08'
updated: '2019-10-23 13:13:53'
tags: [传统运维]
permalink: /articles/2019/10/21/1571649068844.html
---
### 给 SSH key 加上密码

```
ssh-keygen -p -f id_dsa
```

### 修改 SSH key 密码（假设原密码 12345，变更为 54321）

```
ssh-keygen -p -P 12345 -N 54321 -f id_dsa
```
