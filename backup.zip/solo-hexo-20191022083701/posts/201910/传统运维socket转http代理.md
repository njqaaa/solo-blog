title: 传统运维 - socket转http代理
date: '2019-10-22 05:39:19'
updated: '2019-10-22 05:40:56'
tags: [传统运维]
permalink: /articles/2019/10/22/1571722759291.html
---
```
/usr/bin/python2 /usr/bin/sslocal -c /etc/shadowsocks.json -d start
```
```
{
    "server":"ec2-18-219-124-1.us-east-2.compute.amazonaws.com",
    "server_port":8383,
    "local_address":"127.0.0.1",
    "local_port":1080,
    "password":"eqwefdss",
    "timeout":300,
    "method":"aes-256-gcm",
    "fast_open":true
}
```

```
/usr/sbin/privoxy --pidfile /run/privoxy.pid --user privoxy /etc/privoxy/config
```

```
forward-socks5 / 127.0.0.1:1080 .
listen-address 0.0.0.0:8118
forward 192.168.*.*/ .
forward 10.*.*.*/ .
forward 127.*.*.*/ .
forward .hfjy.com/ .
```

[Privoxy教程
](https://segmentfault.com/a/1190000019352916)
