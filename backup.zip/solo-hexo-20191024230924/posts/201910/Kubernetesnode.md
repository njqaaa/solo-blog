title: Kubernetes - node
date: '2019-10-21 16:52:58'
updated: '2019-10-23 13:12:48'
tags: [Kubernetes]
permalink: /articles/2019/10/21/1571647978787.html
---
```
kubectl taint nodes cn-hangzhou.10.111.64.122 node-role.kubernetes.io/master=:NoSchedule

kubectl taint nodes cn-hangzhou.10.111.64.122 node-role.kubernetes.io/master:NoSchedule-
```

### 将 k8s-node1 节点设置为不可调度模式

```
kubectl cordon k8s-node1
```

### 将当前运行在 k8s-node1 节点上的容器驱离

```
kubectl drain k8s-node1 
```

### 执行完维护后，将节点重新加入调度

```
kubectl uncordon k8s-node1
```
