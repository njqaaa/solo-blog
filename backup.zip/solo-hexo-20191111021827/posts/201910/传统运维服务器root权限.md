title: 传统运维 - 服务器root权限
date: '2019-10-23 14:52:19'
updated: '2019-10-24 18:39:05'
tags: [传统运维]
permalink: /articles/2019/10/23/1571813539473.html
---
* 登录服务器 root 用户
  * 现状
    * 通过 jumpserver 按需开权限
      * 问题：麻烦、效率低
    * 通过 jenkins 服务器的 s-user 用户登录远程服务器 root 用户
      * 问题
        * 危险
        * 可以登录所有服务器的 root
        * 可以 sudo su - qinming，qinming 用户下的 Key 可以登录所有服务器的 dev （该 Key 为 Jenkins 发布使用）
  * 解决思路
    * 生成 2 个 SSH Key
      * Key A 登录所有敏感服务器
      * Key B 登录所有非敏感服务器
    * Jenkins 的 s-user 同时拥有 Key A 和 Key B
    * 另外开一台服务器，仅存在 Key B （给予部分人员 s-user 权限）
