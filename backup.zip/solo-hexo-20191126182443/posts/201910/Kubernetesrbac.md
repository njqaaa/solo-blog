title: Kubernetes - rbac
date: '2019-10-25 14:21:16'
updated: '2019-10-25 14:21:16'
tags: [Kubernetes]
permalink: /articles/2019/10/25/1571984476513.html
---
```
apiVersion: v1
kind: ServiceAccount
metadata:
  name: adminxxxxxx
  namespace: kube-system

---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: admin-hehe
  labels:
    kubernetes.io/cluster-service: "true"
    addonmanager.kubernetes.io/mode: Reconcile
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: cluster-admin
subjects:
- kind: ServiceAccount
  name: adminxxxxxx
  namespace: kube-system
```
### 验证
```
kubectl -n kube-system get sa adminxxxxxx
kubectl get clusterrolebindings admin-hehe
```
