title: Ldap - zabbix
date: '2019-10-22 05:13:28'
updated: '2019-10-22 05:14:27'
tags: [Ldap]
permalink: /articles/2019/10/22/1571721208875.html
---
![image.png](https://img.hacpai.com/file/2019/10/image-43449d8e.png)

