title: Jenkins - 环境分类
date: '2019-10-23 14:07:17'
updated: '2019-10-23 14:07:17'
tags: [Jenkins]
permalink: /articles/2019/10/23/1571810837264.html
---
* 环境分类
  * dev
    * 描述
      * 开发环境
    * 用途
      * 开发联调自测
    * 主要服务对象
      * 开发
    * 部署资源
      * 私有云
  * test
    * 描述
      * 测试环境
    * 用途
      * 测试验收
    * 主要服务对象
      * 测试、产品
    * 部署资源
      * 私有云
  * offline-sj
    * 描述
      * 试讲环境的预发布环境
    * 用途
      * 验收环境
    * 主要服务对象
      * 测试、产品
    * 部署资源
      * 公有云
  * offline
    * 描述
      * 生产环境的预发布环境
    * 用途
      * 验收环境
    * 主要服务对象
      * 测试、产品
    * 部署资源
      * 公有云
  * sj
    * 描述
      * 试讲环境
    * 用途
      * 对外部用户提供
    * 主要服务对象
      * 新入职老师
    * 部署资源
      * 公有云
  * online
    * 描述
      * 生产环境
    * 用途
      * 对外部用户提供
    * 主要服务对象
      * 用户
    * 部署资源
      * 公有云
  * 域名规则
    * 如线上域名为 [www.hfjy.com](http://www.hfjy.com) ，则各环境如下
    * dev
      * 标识符
        * d-
      * demo
        * d-[www.hfjy.com](http://www.hfjy.com)
      * 第三方资源（MySQL、Redis 等）
        * 独立
    * test
      * 标识符
        * t-
      * demo
        * t-[www.hfjy.com](http://www.hfjy.com)
      * 第三方资源（MySQL、Redis 等）
        * 独立
    * offline-sj
      * 标识符
        * o-sj-
      * demo
        * o-sj-[www.hfjy.com](http://www.hfjy.com)
      * 第三方资源（MySQL、Redis 等）
        * 与试讲共用
    * offline
      * 标识符
        * o-
      * demo
        * o-[www.hfjy.com](http://www.hfjy.com)
      * 第三方资源（MySQL、Redis 等）
        * 与生产共用
    * sj
      * 标识符
        * sj-
      * demo
        * sj-[www.hfjy.com](http://www.hfjy.com)
      * 第三方资源（MySQL、Redis 等）
        * 与试讲环境的预发布共用
      * 注意
      * 不是所有项目都有以上所有环境
      * 非生产环境仅支持 https 访问
