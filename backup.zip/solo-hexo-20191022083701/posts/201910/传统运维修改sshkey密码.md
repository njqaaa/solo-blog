title: 传统运维 - 修改ssh key密码
date: '2019-10-21 09:11:08'
updated: '2019-10-21 09:11:08'
tags: [传统运维]
permalink: /articles/2019/10/21/1571649068844.html
---
### 给ssh key加上密码
```
ssh-keygen -p -f id_dsa
```

### 修改ssh key密码（假设原密码12345，变更为54321）
```
ssh-keygen -p -P 12345 -N 54321 -f id_dsa
```
