title: 传统运维 - jumpserver api
date: '2019-10-23 15:43:22'
updated: '2019-10-24 18:38:50'
tags: [传统运维]
permalink: /articles/2019/10/23/1571816602789.html
---
### jumpserver API 地址：http://${jumpserver_domain}/docs/

### 场景：获取登录信息，主要取得 token，后续会用到

```
curl -X POST http://${jumpserver_domain}/api/users/v1/auth/ -H 'Content-Type: application/json' -d '{"username": "nijianqiang", "password": "password"}' | jq
```

![image.png](https://img.hacpai.com/file/2019/10/image-104bd9f5.png)

### 场景：获取 node id（服务器文件夹，用于分类），后续会使用

```
curl -X GET --header 'Accept: application/json'  -H 'Authorization: Bearer 4a119ec01ae845c5a8abc53e0dccf5b2' 'http://${jumpserver_domain}/api/assets/v1/nodes/' | jq
```

![image.png](https://img.hacpai.com/file/2019/10/image-4184245c.png)

### 场景：获取 admin_user id，后续会用到

```
curl -s -X GET --header 'Accept: application/json'  -H 'Authorization: Bearer 4a119ec01ae845c5a8abc53e0dccf5b2' 'http://${jumpserver_domain}/api/assets/v1/admin-user/' | jq
```

![image.png](https://img.hacpai.com/file/2019/10/image-36adc443.png)

### 场景：新增一台 ip 为 192.168.1.101 并且主机名为 test101 的服务器（理论上需要先调用查询接口：ip 与 hostname 是否存在）

```
curl -X POST --header 'Content-Type: application/json' --header 'Accept: application/json' -H 'Authorization: Bearer 4a119ec01ae845c5a8abc53e0dccf5b2' -d '{  
   "id": "3ff278f2-39de-11e9-a579-0ab2eca1a3c7",  
   "ip": "192.168.1.101",  
   "hostname": "test101",  
   "port": 22,  
   "platform": "Linux",  
   "is_active": true,  
   "admin_user": "2e33695d-515e-409c-b4fd-dc64684a1215",  
   "nodes": [  
     "a9f7995b-e0b0-454d-8f08-04e4fb3de155"  
   ]  
 }' 'http://${jumpserver_domain}/api/assets/v1/assets/'
```

```
4a119ec01ae845c5a8abc53e0dccf5b2 token  
3ff278f2-39de-11e9-a579-0ab2eca1a3c7 随机的uuid（yum install uuid）  
192.168.1.101 新增的ip（不可重复）  
test101 主机名（不可重复）  
2e33695d-515e-409c-b4fd-dc64684a1215 admin_user id  
a9f7995b-e0b0-454d-8f08-04e4fb3de155 node id
```

![image.png](https://img.hacpai.com/file/2019/10/image-fe0d4eed.png)

### 场景：把 ip 为 192.168.1.101 的服务器，信息更新。例如把 ip 变更为 192.168.1.202，主机名为 test202

```
curl -X PUT --header 'Content-Type: application/json' --header 'Accept: application/json' -H 'Authorization: Bearer 4a119ec01ae845c5a8abc53e0dccf5b2' -d '{  
   "id": "3ff278f2-39de-11e9-a579-0ab2eca1a3c7",  
   "ip": "192.168.1.202",  
   "hostname": "test202",  
   "port": 22,  
   "platform": "Linux",  
   "is_active": true,  
   "admin_user": "2e33695d-515e-409c-b4fd-dc64684a1215",  
   "nodes": [  
     "a9f7995b-e0b0-454d-8f08-04e4fb3de155"  
   ]  
 }' 'http://${jumpserver_domain}/api/assets/v1/assets/3ff278f2-39de-11e9-a579-0ab2eca1a3c7/?ip=192.168.1.101'
```

![image.png](https://img.hacpai.com/file/2019/10/image-c584ffaf.png)
