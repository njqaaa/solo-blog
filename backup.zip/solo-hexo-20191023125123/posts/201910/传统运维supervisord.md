title: 传统运维 - supervisord
date: '2019-10-22 13:40:45'
updated: '2019-10-23 12:29:55'
tags: [传统运维]
permalink: /articles/2019/10/22/1571722845805.html
---
```
[program:git-up-nginx]
user=dev
command=/opt/bin/git-up-nginx.sh
autostart=true
startsecs=5
autorestart=true
startretries=3
stderr_logfile=/var/log/supervisor/git-up-nginx-err.log
stdout_logfile=/var/log/supervisor/git-up-nginx-out.log
stopsignal=INT

[supervisord]
```
