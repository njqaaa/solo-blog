title: Docker - 调试
date: '2019-10-21 15:51:48'
updated: '2019-10-23 13:14:22'
tags: [Docker]
permalink: /articles/2019/10/21/1571644308871.html
---
### 非 cmd 启动的容器

```
--entrypoint=""
```

### 显示命令详情

```
docker ps --no-trunc
```

### 调试

```
http://man7.org/linux/man-pages/man7/capabilities.7.html

nicolaka/netshoot imwithye/htop
container_Id=18471c10e6e4
image_name=nicolaka/netshoot
docker run --rm -it --cap-add sys_admin --cap-add sys_ptrace --net=container:${container_Id} --pid=container:${container_Id} ${image_name} /bin/bash
```
