title: Mysql - slowlog
date: '2019-10-21 17:04:13'
updated: '2019-10-23 13:15:45'
tags: [Mysql]
permalink: /articles/2019/10/21/1571648653371.html
---
```
mysql> show variables like 'slow_query%';
+---------------------+--------------------------------+
| Variable_name       | Value                          |
+---------------------+--------------------------------+
| slow_query_log      | ON                             |
| slow_query_log_file | /usr/local/mysql/data/slow.log |
+---------------------+--------------------------------+
```

```
mysql> show variables like 'long_query_time';
+-----------------+----------+
| Variable_name   | Value    |
+-----------------+----------+
| long_query_time | 1.000000 |
+-----------------+----------+
```

```
set global long_query_time=2;
```

```
set global log_output='TABLE';
```

```
mysql> show variables like '%log_output%';
```

### 执行一条慢查询 SQL 语句

```
mysql> select sleep(2);
```

### 查看是否生成慢查询日志

```
ls /usr/local/mysql/data/slow.log
```

### 查询总计多少 slow

```
show global status like '%Slow_queries%'
```
