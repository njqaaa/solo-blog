title: Jenkins - scripts脚本用途说明for dir
date: '2019-10-24 14:55:46'
updated: '2019-10-24 18:32:54'
tags: [Docker]
permalink: /articles/2019/10/24/1571900146063.html
---
* ansible-hosts
  * ansible 使用的 hosts 文件
  * 被/etc/ansible 所软链
* cdn
  * 主要用于部分项目发布后吊阿里云清除 cdn 缓存
* config_xml
  * 用户 test 环境打包的版本号更新至生产 job
  * 无需人为接入
* exclude
  * ansible synchronize 发布时，根据``${project}/${app_deploy_type}``，做文件过滤
* mapping
  * 健康检查使用
  * 文件名
    * ``${group}-${project}``
  * 内容
    * 第一列：``${group}/${project}``
    * 第二列：``${app_deploy_type}``
    * 第三列：健康检查接口
* ops
	* 运维编写的部分脚本
	* 使用Jenkins ui 定时任务模式
* temp
	* 好像然并卵，尽量别删，省的有坑。
