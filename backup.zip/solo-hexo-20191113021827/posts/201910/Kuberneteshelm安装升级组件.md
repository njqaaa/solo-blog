title: Kubernetes - helm 安装/升级 组件
date: '2019-10-23 14:38:04'
updated: '2019-10-23 15:50:26'
tags: [Kubernetes]
permalink: /articles/2019/10/23/1571812684005.html
---
### 安装

```
helm install traefik stable/traefik --set replicas=1  
```

### 升级

```
helm upgrade traefik stable/traefik  -f <(helm get values traefik) --set externalTrafficPolicy=Local,ssl.enforced=false  
```
