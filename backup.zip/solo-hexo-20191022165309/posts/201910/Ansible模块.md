title: Ansible - 模块
date: '2019-10-21 17:12:23'
updated: '2019-10-21 17:12:23'
tags: [Ansible]
permalink: /articles/2019/10/21/1571649143294.html
---
  - shell
    - chdir
  - script
    - creates=/opt/testfile
    - removes=/opt/testfile
  - fetch
  - copy
  - file
    - path=/testdir/abd state=directory owner=zsy group=zsy recurse=yes 
  - shell
  - synchronize
  - blockinfile 
    - path=/tmp/111 block="hehe" marker="#test"
  - yum
    - name=telnet disable_gpg_check=yes enablerepo=local


- 小技巧
  - 指定某台主机运行
    - delegate_to: somehosts
  - ansible本机运行
    - connection: local
  - 只运行一次
    - run_once: true
