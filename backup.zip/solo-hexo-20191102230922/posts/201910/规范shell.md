title: 规范 - shell
date: '2019-10-22 13:32:33'
updated: '2019-10-24 18:36:54'
tags: [规范]
permalink: /articles/2019/10/22/1571722353743.html
---
* 脚本目录
  * /opt/bin
* 注释
  * 脚本最上方写明该脚本的作用。
  * function 上方写明该方法的作用。
* 命名规则
  * 脚本名
    * 需中线分割，小写
    * demo：[check-xxx.sh](http://check-xxx.sh)
  * 变量
    * 需下划线分割。
      * 自定义变量，需小写
      * demo：gitlab_group
    * 引用其他服务变量，需要大写
      * demo： JENKINS_HOME
  * function
    * 需驼峰
      * demo： getAllService()
* 配置文件
  * 使用 env.sh
