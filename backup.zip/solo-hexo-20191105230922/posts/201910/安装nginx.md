title: 安装 - nginx
date: '2019-10-22 15:35:11'
updated: '2019-10-23 13:15:27'
tags: [安装部署]
permalink: /articles/2019/10/22/1571729711322.html
---
### 所需模块（非必选）

[nginx_upstream_check_module](https://github.com/xiaokai-wang/nginx_upstream_check_module)
[nginx-upsync-module](https://github.com/weibocom/nginx-upsync-module.git)
[ngx_devel_kit](https://github.com/simplresty/ngx_devel_kit.git)
[lua-nginx-module](https://github.com/openresty/lua-nginx-module.git)
[ngx_http_consistent_hash](https://github.com/replay/ngx_http_consistent_hash.git)
[nginx-module-vts](https://github.com/vozlt/nginx-module-vts.git)

### 使用 lua

```
wget http://luajit.org/download/LuaJIT-2.0.5.tar.gz
tar -xzvf LuaJIT-2.0.5.tar.gz
cd LuaJIT-2.0.5
make
make install PREFIX=/usr/local/luajit
export LUAJIT_LIB=/usr/local/luajit/lib
export LUAJIT_INC=/usr/local/luajit/include/luajit-2.0
```

### 使用 nginx_upstream_check_module

```
cd /usr/local/src/nginx-1.14.0
patch -p1 < /usr/local/src/nginx_upstream_check_module/check_1.12.1+.patch
```

### 编译命令

```
./configure
--prefix=/usr/local/nginx \
--sbin-path=/usr/local/nginx/sbin/nginx \
--conf-path=/etc/nginx/nginx.conf \
--error-log-path=/var/log/nginx/error.log \
--http-log-path=/var/log/nginx/access.log \
--with-http_ssl_module \
--with-http_realip_module \
--with-http_addition_module \
--with-http_sub_module \
--with-http_dav_module \
--with-http_flv_module \
--with-http_gzip_static_module \
--with-http_stub_status_module \
--with-mail \
--with-mail_ssl_module \
--with-openssl-opt=enable-tlsext \
--with-stream \
--with-http_v2_module \
--add-module=/usr/local/src/nginx_upstream_check_module \
--add-module=/usr/local/src/nginx-upsync-module \
--with-ld-opt=-Wl,-E \
--add-module=/usr/local/src/ngx_devel_kit \
--add-module=/usr/local/src/lua-nginx-module \
--add-module=/usr/local/src/ngx_http_consistent_hash \
--add-module=/usr/local/src/nginx-module-vts
```

### nginx.conf

```
user dev; # nginx启动用户
worker_processes auto; # 打开进程数等于CPU核数
worker_cpu_affinity auto; # cpu亲和
worker_rlimit_nofile  65535;
error_log  /var/log/nginx/error.log error;
pid        /var/run/nginx.pid;

events {
    use epoll; # io多路复用
    worker_connections 10240;# 每一个worker进程能够处理多少连接
}

http {
    include         /etc/nginx/mime.types;
    default_type  application/octet-stream;
    charset utf-8;

    log_format main '$time_iso8601\t$uri\t$args\t$status\t$request_time\t$upstream_response_time\t$remote_addr\t$uid_got$uid_set\t'
                    '$http_host\t$request_method\t$body_bytes_sent\t$http_referer\t$http_user_agent\t$upstream_addr\t$server_protocol\t'
                    '$http_x_forwarded_for\t$arg_roomId\t$http_cookie\t$http_uuid\t$http_x_hf_learn_session_id\t$server_port';

    access_log /var/log/nginx/access-$host.log main;

    server_tokens off; # 隐藏nginx版本号
    keepalive_timeout  65;
    keepalive_requests 8192;
    sendfile           on; # 立即将数据从磁盘读到OS缓存，不涉及用户空间
    tcp_nopush on; # sendfile开启下，提高网络包的传输效率。
#    tcp_nodelay on; # keeyalive连接下，提高网络包传输的实时性。

    gzip on;
    gzip_min_length 1k; # 大于1K的才压缩
    gzip_buffers 4 16k;
    gzip_comp_level 4; # 压缩级别，1-10
    gzip_types text/plain application/javascript application/x-javascript text/javascript text/xml text/css application/json; # 图片不压缩

    gzip_vary off; # 是否添加“Vary: Accept-Encoding”响应头
    gzip_disable "MSIE [1-6]\."; # 忽略IE6
    gzip_http_version 1.1;
    proxy_connect_timeout 60s;
    proxy_read_timeout 120s;
    proxy_send_timeout 120s;

    proxy_http_version 1.1;
    proxy_set_header Connection "";

    proxy_set_header host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-Proto $scheme;

    client_header_buffer_size 512k;
    client_body_buffer_size 1024k;
    fastcgi_buffer_size 1024k;
    fastcgi_buffers 6 256k;
    fastcgi_busy_buffers_size 1024k;

    server_names_hash_max_size 1024;
    map $http_upgrade $connection_upgrade {
      default upgrade;
      ''      close;
    }


    server {
        listen 80;
        server_name _;
        access_log off;
        location = /nginx_status {
            stub_status on;
        }

        location = /upstream_status {
            check_status;
        }
        location = /upstream_show {
            upstream_show;
        }
    }

    include conf.d/*.conf;

}
```
