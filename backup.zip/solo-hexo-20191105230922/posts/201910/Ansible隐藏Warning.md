title: Ansible - 隐藏Warning
date: '2019-10-29 15:27:28'
updated: '2019-10-29 15:27:28'
tags: [Ansible]
permalink: /articles/2019/10/29/1572334048609.html
---
### when条件Warning
```
 [WARNING]: conditional statements should not include jinja2 templating

delimiters such as {{ }} or {% %}. Found: PIONEER is defined and PIONEER == '{{

pioneer }}' and REGION == '{{ region }}'
```

### 
```
vim /usr/lib/python2.7/site-packages/ansible/playbook/conditional.py + 118  
注释以下内容  
#        if templar.is_template(conditional):  
#            display.warning('conditional statements should not include jinja2 '  
#                            'templating delimiters such as {{ }} or {%% %%}. '  
#                            'Found: %s' % conditional)
```
