title: Kubernetes - helm chartmuseum
date: '2019-10-23 14:37:21'
updated: '2019-10-23 15:13:29'
tags: [Kubernetes]
permalink: /articles/2019/10/23/1571812641180.html
---
### 安装

```
curl -LO https://s3.amazonaws.com/chartmuseum/release/latest/bin/linux/amd64/chartmuseum

helm plugin install https://github.com/chartmuseum/helm-push
```

```
chartmuseum   --port=8080 --storage="alibaba" --storage-alibaba-bucket="hf-crm-read" --storage-alibaba-prefix="" --storage-alibaba-endpoint="[oss-cn-hangzhou.aliyuncs.com](http://oss-cn-hangzhou.aliyuncs.com)"

helm repo add chartmuseum [http://localhost:8080](http://localhost:8080)

helm push mychart/ chartmuseum
```
