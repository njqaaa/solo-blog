title: 传统运维 - iptables概念
date: '2019-10-21 09:12:46'
updated: '2019-10-22 07:43:00'
tags: [传统运维]
permalink: /articles/2019/10/21/1571649166688.html
---
- 用户通过iptables这个代理，将用户的安全设定执行到对应的"安全框架"中。
  - iptables其实是一个命令行工具，位于用户空间
    - 并不能算是真正意义上的服务，而应该算是内核提供的功能。 
  - netfilter位于内核空间。
    - 网络地址转换(Network Address Translate)
    - 数据包内容修改
    - 数据包过滤的防火墙功能
- 规则处理
  - 源地址、目的地址、传输协议（如TCP、UDP、ICMP）和服务类型（如HTTP、FTP和SMTP）等。
  - 放行（accept）、拒绝（reject）和丢弃（drop）等。
- 链
  - "路由前"、"转发"、"路由后"
  - 英文名是 PREROUTING、FORWARD、POSTROUTING
- 表
  - filter表
    - 负责过滤功能，防火墙；内核模块：iptables_filter
    - INPUT，FORWARD，OUTPUT
  - nat表
    - network address translation，网络地址转换功能；内核模块：iptable_nat
    - PREROUTING，OUTPUT
  - mangle表
    - 拆解报文，做出修改，并重新封装 的功能；iptable_mangle
    - PREROUTING，INPUT，FORWARD，OUTPUT，POSTROUTING
  - raw表
    - 关闭nat表上启用的连接追踪机制；iptable_raw
    - PREROUTING，OUTPUT，POSTROUTING（centos7中还有INPUT，centos6中没有）
  - 
- 链表关系
  - PREROUTING      的规则可以存在于：raw表，mangle表，nat表。
  - INPUT          的规则可以存在于：mangle表，filter表，（centos7中还有nat表，centos6中没有）。
  - FORWARD         的规则可以存在于：mangle表，filter表。
  - OUTPUT         的规则可以存在于：raw表mangle表，nat表，filter表。
  - POSTROUTING      的规则可以存在于：mangle表，nat表。

