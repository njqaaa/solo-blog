title: Prometheus - 目录结构
date: '2019-10-22 15:57:04'
updated: '2019-10-23 13:11:50'
tags: [Prometheus]
permalink: /articles/2019/10/22/1571731024256.html
---
```
/opt/
├── app
│   ├── alertmanager
│   │   ├── alertmanager
│   │   ├── alertmanager.yml -> /opt/app/prometheus/alertmanager.d/alertmanager.yml
│   │   ├── amtool
│   ├── blackbox_exporter
│   │   ├── blackbox_exporter
│   │   ├── blackbox.yml -> /opt/app/prometheus/blackbox_exporter/blackbox.yml
│   ├── node_exporter
│   │   ├── node_exporter
│   ├── prometheus
│   │   ├── alertmanager.d
│   │   │   └── alertmanager.yml
│   │   ├── blackbox_exporter
│   │   │   └── blackbox.yml
│   │   ├── console_libraries
│   │   │   ├── menu.lib
│   │   │   └── prom.lib
│   │   ├── consoles
│   │   │   ├── index.html.example
│   │   │   ├── node-cpu.html
│   │   │   ├── node-disk.html
│   │   │   ├── node.html
│   │   │   ├── node-overview.html
│   │   │   ├── prometheus.html
│   │   │   └── prometheus-overview.html
│   │   ├── http.d
│   │   │   ├── base.yml
│   │   │   ├── lms.yml
│   │   │   ├── office-url.yml
│   │   │   ├── study.yml
│   │   │   └── web.yml
│   │   ├── prometheus
│   │   ├── prometheus-webhook-dingtalk.d
│   │   │   └── common.tmpl
│   │   ├── prometheus.yml
│   │   ├── promtool
│   │   ├── rules.d
│   │   │   ├── blackbox.yml
│   │   │   ├── ecs.yml
│   │   │   ├── eip.yml
│   │   │   ├── exporter.yml
│   │   │   ├── jvm.yml
│   │   │   ├── kafka.yml
│   │   │   ├── lms.yml
│   │   │   ├── ops.yml
│   │   │   ├── rds.yml
│   │   │   ├── slb.yml
│   │   │   ├── url.yml
│   │   │   └── zookeeper.yml
│   │   ├── scripts
│   │   │   ├── auto-pull-and-reload.sh
│   │   │   ├── check-duplication-instance.sh
│   │   │   ├── config.sh
│   │   │   ├── consul
│   │   │   │   ├── deregister-node_export.sh
│   │   │   │   └── register-node_exporter.sh
│   │   │   ├── HFJY_AliyunLogToPrometheus_v4.py
│   │   │   ├── HFJY_AliyunNginxLog_Internal_v1.py
│   │   │   ├── HFJY_CDN_monitor.py
│   │   │   ├── hfjy_exporter_v1.conf
│   │   │   ├── HFJY_Mongodb_monitor.py
│   │   │   ├── HFJY_OSS_monitor_V3.py
│   │   │   ├── HFJY_RDS_monitor_v4.5.py
│   │   │   ├── HFJY_Redis_monitor_v2.py
│   │   │   ├── HFJY_SLB_Describe_v2.py
│   │   │   ├── HFJY_SLB_monitor_v1.py
│   │   │   ├── HFJY_VPC_monitor_v2.py
│   │   │   ├── RDS_config_v2.json
│   │   │   ├── send_voice.py
│   │   │   ├── silence
│   │   │   │   ├── silence-daily.sh
│   │   │   │   ├── silence-ecs-list
│   │   │   │   ├── silence-ecs.sh
│   │   │   │   ├── silence-rds-list
│   │   │   │   └── silence-rds.sh
│   │   │   └── test.py
│   │   ├── supervisord.d
│   │   │   ├── alertmanager.ini
│   │   │   ├── blackbox_exporter.ini
│   │   │   ├── HFJY_Exporter_Webmonitor.ini
│   │   │   ├── HFJY_VPC_monitor_v2.ini
│   │   │   ├── node_exporter.ini
│   │   │   ├── php-fpm-exporter.ini
│   │   │   ├── prometheus-webhook-dingtalk.ini
│   │   │   ├── pushgateway.ini
│   │   │   ├── thanos-query.ini
│   │   │   └── thanos-sidecar.ini
│   │   ├── system.d
│   │   │   └── prometheus.service
│   │   └── tcp.d
│   │       └── base.yml
│   ├── prometheus-webhook-dingtalk
│   │   ├── common.tmpl -> /opt/app/prometheus/prometheus-webhook-dingtalk.d/common.tmpl
│   │   └── prometheus-webhook-dingtalk
│   ├── pushgateway
│   │   └── pushgateway
│   └── thanos
│       └── thanos
├── bin
│   ├── register
│   │   ├── catalog.sh
│   │   ├── config.sh
│   │   ├── jmx_export-jetty.sh
│   │   ├── jmx_export-tomcat.sh
│   │   ├── nginx-vts-exporter.sh
│   │   ├── node_export.sh
│   │   └── php-fpm.sh
│   ├── send_voice.py
│   ├── silence
│   │   ├── config.sh
│   │   ├── silence-daily.sh
│   │   ├── silence-ecs-list
│   │   ├── silence-ecs.sh
│   │   ├── silence-rds-list
│   │   └── silence-rds.sh
│   ├── ssu
│   └── sysinfo.py
├── supervisord.conf
└── supervisord.d -> /opt/app/prometheus/supervisord.d
```
