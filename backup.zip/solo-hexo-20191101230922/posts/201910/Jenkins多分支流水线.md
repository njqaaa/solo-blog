title: Jenkins - 多分支流水线
date: '2019-10-23 13:10:56'
updated: '2019-10-30 17:11:17'
tags: [Jenkins]
permalink: /articles/2019/10/23/1571807456042.html
---
### pipeline 语法

`` http://${jenkins_domain}/pipeline-syntax/ ``

### 多分支模式

#### 需代码 Git 仓库中增加.Jenkinsfile-dev .Jenkinsfile-test

#### 需要 GitLab 配置[webhook](https://gitlab.hfjy.com/front/xue-client-webapp/settings/integrations)

* demo:  `` http://${jenkins_domain}/project/front-dev/xue-client-webapp ``

### pipeline 调用 shell，减少.Jenkinsfile 变更频率。

#### dev demo

```
pipeline {
    agent any
    parameters {
        choice choices: ['go'], description: '部署方式', name: 'APP_DEPLOY_TYPE'
    }

    triggers {
        gitlab(triggerOnPush: true, triggerOnMergeRequest: true, branchFilterType: 'All')
    }

    stages {
        stage('check auto build'){
            steps {
                script {
                    try {
                        wrap([$class: 'BuildUser']) {
                            sh '${JENKINS_SHELL_PATH}/check-build.sh'
                        }
                    }catch(e){
                        echo 'no auto build'
                        currentBuild.result = "ABORTED"
                        sh 'curl -n -X POST ${BUILD_URL}doDelete'
                        error
                    }
                }
            }
        }
        stage('up jenkins desc'){
            steps {
                script {
                    currentBuild.displayName="${BUILD_NUMBER}"
                    sh '${JENKINS_SHELL_PATH}/git.sh'
                }
            }
        }
        stage('go something'){
            steps {
                script{
                    sh '${JENKINS_SHELL_PATH}/go.sh'
                }
            }
        }
        stage('release code') {
            steps {
                script {
                    sh '${JENKINS_SHELL_PATH}/release-${APP_DEPLOY_TYPE}.sh'
                }
            }
        }
    }

    post {
        success {
            script {
                def status = "SUCCESS"
                try {
                     wrap([$class: 'BuildUser']) {
                        sh "bash ${JENKINS_SHELL_PATH}/send-dingding.sh '${status}' ${BUILD_USER} 本次发布成功"
                    }
                }catch(e){
                        sh "bash ${JENKINS_SHELL_PATH}/send-dingding.sh '${status}' jenkins 本次发布成功"
                }
            }
        }
        failure {
            script {
                def status = "FAILED"
                try {
                     wrap([$class: 'BuildUser']) {
                        sh "bash ${JENKINS_SHELL_PATH}/send-dingding.sh '${status}' ${BUILD_USER}"
                    }
                }catch(e){
                        sh "bash ${JENKINS_SHELL_PATH}/send-dingding.sh '${status}' jenkins"
                }
            }
        }
    }
}
```

#### test demo

```
pipeline {
    agent any
    parameters {
        string(name: 'TAG_VERSION', defaultValue:  '0.0.0', description: 'tag版本')
        choice choices: ['go'], description: '部署方式', name: 'APP_DEPLOY_TYPE'
    }

    triggers {
        gitlab(triggerOnPush: true, triggerOnMergeRequest: true, branchFilterType: 'All')
    }

    stages {
        stage('check auto build'){
            steps {
                script {
                    wrap([$class: 'BuildUser']) {
                        try {
                            echo "${BUILD_USER}"
                        }catch(e){
                            echo 'no auto build'
                            currentBuild.result = "ABORTED"
                            sh 'curl -n -X POST ${BUILD_URL}doDelete'
                            error
                        }
                    }
                }
            }
        }
        stage('up jenkins desc'){
            steps {
                script {
                    if (TAG_VERSION == "0.0.0"){
                        currentBuild.displayName="${BUILD_NUMBER}"
                    }else{
                        currentBuild.displayName="${TAG_VERSION}"
                    }
                    sh '${JENKINS_SHELL_PATH}/git.sh'
                }
            }
        }
        stage('go something'){
            steps {
                script{
                    sh '${JENKINS_SHELL_PATH}/go.sh'
                }
            }
        }
        stage('backup code') {
            steps {
                script {
                    if (TAG_VERSION == "0.0.0"){
                        echo 'TAG_VERSION为0.0.0，不备份'
                    }else{
                        echo '备份'
                        sh '${JENKINS_SHELL_PATH}/backup.sh'
                        sh 'bash ${JENKINS_SHELL_PATH}/update-config.sh'
                    }
                }
            }
        }
        stage('release code') {
            steps {
                script {
                    sh '${JENKINS_SHELL_PATH}/release-${APP_DEPLOY_TYPE}.sh'
                }
            }
        }
    }

    post {
        success {
            script {
                def status = "SUCCESS"
                try {
                     wrap([$class: 'BuildUser']) {
                        sh "bash ${JENKINS_SHELL_PATH}/send-dingding.sh '${status}' ${BUILD_USER} 本次发布成功"
                    }
                }catch(e){
                        sh "bash ${JENKINS_SHELL_PATH}/send-dingding.sh '${status}' jenkins 本次发布成功"
                }
            }
        }
        failure {
            script {
                def status = "FAILED"
                try {
                     wrap([$class: 'BuildUser']) {
                        sh "bash ${JENKINS_SHELL_PATH}/send-dingding.sh '${status}' ${BUILD_USER}"
                    }
                }catch(e){
                        sh "bash ${JENKINS_SHELL_PATH}/send-dingding.sh '${status}' jenkins"
                }
            }
        }
    }
}
```

#### test 之后的环境 demo

```
pipeline {
//    agent any    
    agent {
        node {
            label 'aliyun-slave'
        }
    }
    stages {
        stage('up jenkins info'){
            steps {
                script {
                    currentBuild.displayName="${TAG_VERSION}"
                }
            }
        }

        stage('release code') {
            steps {
                script {
                    echo "发布代码..."
                    sh '${JENKINS_SHELL_PATH}/release-${APP_DEPLOY_TYPE}.sh'

                }
            }
        }
    }
    post {
        success {
            script {
                def status = "SUCCESS"
                wrap([$class: 'BuildUser']) {
                    sh "bash ${JENKINS_SHELL_PATH}/send-dingding.sh '${status}' ${BUILD_USER} 本次发布成功"
                }
            }
        }
        failure {
            script {
                def status = "FAILED"
                wrap([$class: 'BuildUser']) {
                    sh "bash ${JENKINS_SHELL_PATH}/send-dingding.sh  '${status}' ${BUILD_USER}"
                }
            }
        }
    }
}
```
