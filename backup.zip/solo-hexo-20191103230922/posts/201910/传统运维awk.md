title: 传统运维 - awk
date: '2019-10-25 16:32:59'
updated: '2019-10-25 16:40:50'
tags: [传统运维]
permalink: /articles/2019/10/25/1571992379724.html
---
### 不打印最后一列
```
echo "a b c d" | awk '{NF-=1;print}'
a b c
```

### 输出结果包含单引号
```
echo 111|awk '{print $0"\047"}'
111'
```
