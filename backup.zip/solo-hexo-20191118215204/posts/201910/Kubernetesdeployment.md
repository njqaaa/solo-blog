title: Kubernetes - deployment
date: '2019-10-21 16:59:35'
updated: '2019-10-23 13:12:37'
tags: [Kubernetes]
permalink: /articles/2019/10/21/1571648375829.html
---
### history 显示详情

```
--record
```

### 变更 pod 数量

```
kubectl scale deployment deployment/review-demo --replicas 3
```

### 查看部署状态

```
kubectl rollout status deployment/review-demo
```

### 查看详情

```
kubectl describe deployment/review-demo
```

### 中止升级

```
kubectl rollout pause deployment/review-demo
```

### 继续升级

```
kubectl rollout resume deployment/review-demo
```

### 查看部署历史

```
kubectl rollout history deployments
```

### 回退至上一个版本

```
kubectl rollout undo deployment/review-demo
```

### 回退至某个版本

```
kubectl rollout undo deployment/review-demo --to-revision=2
```

### 修改镜像

```
kubectl set image deployment/review-demo review-demo=library/review-demo:0.0.1
```
