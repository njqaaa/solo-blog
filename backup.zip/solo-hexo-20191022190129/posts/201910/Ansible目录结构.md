title: Ansible - 目录结构
date: '2019-10-21 17:34:15'
updated: '2019-10-22 15:57:33'
tags: [Ansible]
permalink: /articles/2019/10/21/1571650454969.html
---
```
├── common  
│   ├── home  
│   │   └── dev  
│   └── opt  
│       ├── bin  
│       │   │   ├── check-service-status.sh  
│       │   │   └── consul.sh  
│       │   ├── changeip.sh  
│       │   ├── check-service-status.sh  
│       │   ├── clean-log.sh  
│       │   ├── consul.sh  
│       │   ├── del_logs.sh  
│       │   ├── get-env.sh  
│       │   ├── register  
│       │   │   ├── catalog.sh  
│       │   │   ├── config.sh  
│       │   │   ├── jmx_export-jetty.sh  
│       │   │   ├── jmx_export-tomcat.sh  
│       │   │   ├── nginx-vts-exporter.sh  
│       │   │   ├── node_export.sh  
│       │   │   └── php-fpm.sh  
│       │   ├── ssu  
│       │   └── sysinfo.py  
│       ├── supervisord.conf  
│       └── supervisord.d  
├── consul  
│   └── opt  
│       └── bin  
│           ├── consul-client  
│           ├── consul-cluster  
│           ├── register-jmx_export-jetty.sh  
│           ├── register-jmx_export-tomcat.sh  
│           ├── register-nginx-vts-exporter.sh  
│           └── register-node_export.sh  
├── go  
│   └── opt  
│       └── bin  
│           │   └── go  
│           ├── go  
│           └── restart-all-go.sh  
├── java  
│   └── opt  
│       ├── app  
│       │   └── jetty-demo  
│       │       ├── bin  
│       │       │   ├── jetty.sh  
│       │       │   └── jetty.sh-20180929  
│       │       ├── etc  
│       │       │   ├── cdi2  
│       │       │   │   ├── jetty-cdi2.xml  
│       │       │   │   └── jetty-web-cdi2.xml  
│       │       │   ├── console-capture.xml  
│       │       │   ├── example-quickstart.xml  
│       │       │   ├── home-base-warning.xml  
│       │       │   ├── jdbcRealm.properties  
│       │       │   ├── jetty-alpn.xml  
│       │       │   ├── jetty-annotations.xml  
│       │       │   ├── jetty-cdi.xml  
│       │       │   ├── jetty.conf  
│       │       │   ├── jetty-connectionlimit.xml  
│       │       │   ├── jetty-debuglog.xml  
│       │       │   ├── jetty-debug.xml  
│       │       │   ├── jetty-deploy.xml  
│       │       │   ├── jetty-gzip.xml  
│       │       │   ├── jetty-http2c.xml  
│       │       │   ├── jetty-http2.xml  
│       │       │   ├── jetty-http-forwarded.xml  
│       │       │   ├── jetty-https.xml  
│       │       │   ├── jetty-http.xml  
│       │       │   ├── jetty-ipaccess.xml  
│       │       │   ├── jetty-jaas.xml  
│       │       │   ├── jetty-jmx-remote.xml  
│       │       │   ├── jetty-jmx.xml  
│       │       │   ├── jetty-logging.xml  
│       │       │   ├── jetty-lowresources.xml  
│       │       │   ├── jetty-plus.xml  
│       │       │   ├── jetty-proxy-protocol-ssl.xml  
│       │       │   ├── jetty-proxy-protocol.xml  
│       │       │   ├── jetty-proxy.xml  
│       │       │   ├── jetty-requestlog.xml  
│       │       │   ├── jetty-rewrite-customizer.xml  
│       │       │   ├── jetty-rewrite.xml  
│       │       │   ├── jetty-setuid.xml  
│       │       │   ├── jetty-spring.xml  
│       │       │   ├── jetty-ssl-context.xml  
│       │       │   ├── jetty-ssl.xml  
│       │       │   ├── jetty-started.xml  
│       │       │   ├── jetty-stats.xml  
│       │       │   ├── jetty-stop.xml  
│       │       │   ├── jetty-threadlimit.xml  
│       │       │   ├── jetty-unixsocket-forwarded.xml  
│       │       │   ├── jetty-unixsocket-http2c.xml  
│       │       │   ├── jetty-unixsocket-http.xml  
│       │       │   ├── jetty-unixsocket-proxy-protocol.xml  
│       │       │   ├── jetty-unixsocket-secure.xml  
│       │       │   ├── jetty-unixsocket.xml  
│       │       │   ├── jetty-webapp.xml  
│       │       │   ├── jetty.xml  
│       │       │   ├── krb5.ini  
│       │       │   ├── README.spnego  
│       │       │   ├── rewrite-compactpath.xml  
│       │       │   ├── sessions  
│       │       │   │   ├── file  
│       │       │   │   │   └── session-store.xml  
│       │       │   │   ├── gcloud  
│       │       │   │   │   └── session-store.xml  
│       │       │   │   ├── hazelcast  
│       │       │   │   │   ├── default.xml  
│       │       │   │   │   └── remote.xml  
│       │       │   │   ├── id-manager.xml  
│       │       │   │   ├── infinispan  
│       │       │   │   │   ├── default.xml  
│       │       │   │   │   └── remote.xml  
│       │       │   │   ├── jdbc  
│       │       │   │   │   ├── datasource.xml  
│       │       │   │   │   ├── driver.xml  
│       │       │   │   │   └── session-store.xml  
│       │       │   │   ├── mongo  
│       │       │   │   │   ├── session-store-by-address.xml  
│       │       │   │   │   └── session-store-by-uri.xml  
│       │       │   │   ├── session-cache-hash.xml  
│       │       │   │   ├── session-cache-null.xml  
│       │       │   │   └── session-data-cache  
│       │       │   │       ├── session-caching-store.xml  
│       │       │   │       └── xmemcached.xml  
│       │       │   ├── spnego.conf  
│       │       │   ├── spnego.properties  
│       │       │   └── webdefault.xml  
│       │       ├── jetty  
│       │       ├── jetty.state  
│       │       ├── lib  
│       │       │   ├── alpn-api-1.1.3.v20160715.jar  
│       │       │   ├── annotations  
│       │       │   │   ├── asm-6.0.jar  
│       │       │   │   ├── asm-commons-6.0.jar  
│       │       │   │   └── javax.annotation-api-1.2.jar  
│       │       │   ├── apache-jsp  
│       │       │   │   ├── org.eclipse.jdt.ecj-3.12.3.jar  
│       │       │   │   ├── org.eclipse.jetty.apache-jsp-9.4.8.v20180619.jar  
│       │       │   │   ├── org.mortbay.jasper.apache-el-8.5.23.jar  
│       │       │   │   └── org.mortbay.jasper.apache-jsp-8.5.23.jar  
│       │       │   ├── apache-jstl  
│       │       │   │   ├── org.apache.taglibs.taglibs-standard-impl-1.2.5.jar  
│       │       │   │   └── org.apache.taglibs.taglibs-standard-spec-1.2.5.jar  
│       │       │   ├── cdi-2-9.4.8.v20180619.jar  
│       │       │   ├── cdi-core-9.4.8.v20180619.jar  
│       │       │   ├── cdi-servlet-9.4.8.v20180619.jar  
│       │       │   ├── ext  
│       │       │   ├── fcgi  
│       │       │   │   ├── fcgi-client-9.4.8.v20180619.jar  
│       │       │   │   └── fcgi-server-9.4.8.v20180619.jar  
│       │       │   ├── http2  
│       │       │   │   ├── http2-common-9.4.8.v20180619.jar  
│       │       │   │   ├── http2-hpack-9.4.8.v20180619.jar  
│       │       │   │   └── http2-server-9.4.8.v20180619.jar  
│       │       │   ├── jaspi  
│       │       │   │   └── javax.security.auth.message-1.0.0.v201108011116.jar  
│       │       │   ├── jetty-alpn-conscrypt-server-9.4.8.v20180619.jar  
│       │       │   ├── jetty-alpn-java-server-9.4.8.v20180619.jar  
│       │       │   ├── jetty-alpn-openjdk8-server-9.4.8.v20180619.jar  
│       │       │   ├── jetty-alpn-server-9.4.8.v20180619.jar  
│       │       │   ├── jetty-annotations-9.4.8.v20180619.jar  
│       │       │   ├── jetty-client-9.4.8.v20180619.jar  
│       │       │   ├── jetty-continuation-9.4.8.v20180619.jar  
│       │       │   ├── jetty-deploy-9.4.8.v20180619.jar  
│       │       │   ├── jetty-gcloud-session-manager-9.4.8.v20180619.jar  
│       │       │   ├── jetty-hazelcast-9.4.8.v20180619.jar  
│       │       │   ├── jetty-http-9.4.8.v20180619.jar  
│       │       │   ├── jetty-infinispan-9.4.8.v20180619.jar  
│       │       │   ├── jetty-io-9.4.8.v20180619.jar  
│       │       │   ├── jetty-jaas-9.4.8.v20180619.jar  
│       │       │   ├── jetty-jaspi-9.4.8.v20180619.jar  
│       │       │   ├── jetty-jmx-9.4.8.v20180619.jar  
│       │       │   ├── jetty-jndi-9.4.8.v20180619.jar  
│       │       │   ├── jetty-memcached-sessions-9.4.8.v20180619.jar  
│       │       │   ├── jetty-nosql-9.4.8.v20180619.jar  
│       │       │   ├── jetty-plus-9.4.8.v20180619.jar  
│       │       │   ├── jetty-proxy-9.4.8.v20180619.jar  
│       │       │   ├── jetty-quickstart-9.4.8.v20180619.jar  
│       │       │   ├── jetty-rewrite-9.4.8.v20180619.jar  
│       │       │   ├── jetty-schemas-3.1.jar  
│       │       │   ├── jetty-security-9.4.8.v20180619.jar  
│       │       │   ├── jetty-server-9.4.8.v20180619.jar  
│       │       │   ├── jetty-servlet-9.4.8.v20180619.jar  
│       │       │   ├── jetty-servlets-9.4.8.v20180619.jar  
│       │       │   ├── jetty-unixsocket-9.4.8.v20180619.jar  
│       │       │   ├── jetty-util-9.4.8.v20180619.jar  
│       │       │   ├── jetty-webapp-9.4.8.v20180619.jar  
│       │       │   ├── jetty-xml-9.4.8.v20180619.jar  
│       │       │   ├── mail  
│       │       │   │   └── javax.mail.glassfish-1.4.1.v201005082020.jar  
│       │       │   ├── servlet-api-3.1.jar  
│       │       │   ├── setuid  
│       │       │   │   ├── jetty-setuid-java-1.0.3.jar  
│       │       │   │   ├── libsetuid-linux.so  
│       │       │   │   └── libsetuid-osx.so  
│       │       │   ├── spring  
│       │       │   │   └── jetty-spring-9.4.8.v20180619.jar  
│       │       │   ├── transactions  
│       │       │   │   └── javax.transaction-api-1.2.jar  
│       │       │   └── websocket  
│       │       │       ├── javax.websocket-api-1.0.jar  
│       │       │       ├── javax-websocket-client-impl-9.4.8.v20180619.jar  
│       │       │       ├── javax-websocket-server-impl-9.4.8.v20180619.jar  
│       │       │       ├── websocket-api-9.4.8.v20180619.jar  
│       │       │       ├── websocket-client-9.4.8.v20180619.jar  
│       │       │       ├── websocket-common-9.4.8.v20180619.jar  
│       │       │       ├── websocket-server-9.4.8.v20180619.jar  
│       │       │       └── websocket-servlet-9.4.8.v20180619.jar  
│       │       ├── license-eplv10-aslv20.html  
│       │       ├── modules  
│       │       │   ├── alpn-impl  
│       │       │   │   ├── alpn-1.8.0_05.mod  
│       │       │   │   ├── alpn-1.8.0_101.mod  
│       │       │   │   ├── alpn-1.8.0_102.mod  
│       │       │   │   ├── alpn-1.8.0_111.mod  
│       │       │   │   ├── alpn-1.8.0_112.mod  
│       │       │   │   ├── alpn-1.8.0_11.mod  
│       │       │   │   ├── alpn-1.8.0_121.mod  
│       │       │   │   ├── alpn-1.8.0_131.mod  
│       │       │   │   ├── alpn-1.8.0_141.mod  
│       │       │   │   ├── alpn-1.8.0_144.mod  
│       │       │   │   ├── alpn-1.8.0_151.mod  
│       │       │   │   ├── alpn-1.8.0_152.mod  
│       │       │   │   ├── alpn-1.8.0_20.mod  
│       │       │   │   ├── alpn-1.8.0_25.mod  
│       │       │   │   ├── alpn-1.8.0_31.mod  
│       │       │   │   ├── alpn-1.8.0_40.mod  
│       │       │   │   ├── alpn-1.8.0_45.mod  
│       │       │   │   ├── alpn-1.8.0_51.mod  
│       │       │   │   ├── alpn-1.8.0_60.mod  
│       │       │   │   ├── alpn-1.8.0_65.mod  
│       │       │   │   ├── alpn-1.8.0_66.mod  
│       │       │   │   ├── alpn-1.8.0_71.mod  
│       │       │   │   ├── alpn-1.8.0_72.mod  
│       │       │   │   ├── alpn-1.8.0_73.mod  
│       │       │   │   ├── alpn-1.8.0_74.mod  
│       │       │   │   ├── alpn-1.8.0_77.mod  
│       │       │   │   ├── alpn-1.8.0_91.mod  
│       │       │   │   ├── alpn-1.8.0_92.mod  
│       │       │   │   ├── alpn-1.8.0.mod  
│       │       │   │   ├── alpn-8.mod  
│       │       │   │   └── alpn-9.mod  
│       │       │   ├── alpn-impl.mod  
│       │       │   ├── alpn.mod  
│       │       │   ├── annotations.mod  
│       │       │   ├── apache-jsp.mod  
│       │       │   ├── apache-jstl.mod  
│       │       │   ├── cdi1.mod  
│       │       │   ├── cdi2.mod  
│       │       │   ├── cdi.mod  
│       │       │   ├── client.mod  
│       │       │   ├── connectionlimit.mod  
│       │       │   ├── conscrypt  
│       │       │   │   └── conscrypt.xml  
│       │       │   ├── conscrypt.mod  
│       │       │   ├── console-capture.mod  
│       │       │   ├── continuation.mod  
│       │       │   ├── debuglog.mod  
│       │       │   ├── debug.mod  
│       │       │   ├── deploy.mod  
│       │       │   ├── deprecated.properties  
│       │       │   ├── ext.mod  
│       │       │   ├── fcgi.mod  
│       │       │   ├── flight-recorder.mod  
│       │       │   ├── gcloud  
│       │       │   │   └── index.yaml  
│       │       │   ├── gcloud-datastore.mod  
│       │       │   ├── gcloud.mod  
│       │       │   ├── gzip.mod  
│       │       │   ├── hawtio  
│       │       │   │   └── hawtio.xml  
│       │       │   ├── hawtio.mod  
│       │       │   ├── hazelcast-embedded-sessions.mod  
│       │       │   ├── hazelcast-remote-sessions.mod  
│       │       │   ├── home-base-warning.mod  
│       │       │   ├── http2c.mod  
│       │       │   ├── http2.mod  
│       │       │   ├── http-forwarded.mod  
│       │       │   ├── http.mod  
│       │       │   ├── https.mod  
│       │       │   ├── ipaccess.mod  
│       │       │   ├── jaas.mod  
│       │       │   ├── jamon  
│       │       │   │   └── jamon.xml  
│       │       │   ├── jamon.mod  
│       │       │   ├── jaspi.mod  
│       │       │   ├── jcl-slf4j.mod  
│       │       │   ├── jminix  
│       │       │   │   └── jminix.xml  
│       │       │   ├── jminix.mod  
│       │       │   ├── jmx.mod  
│       │       │   ├── jmx-remote.mod  
│       │       │   ├── jndi.mod  
│       │       │   ├── jolokia  
│       │       │   │   └── jolokia.xml  
│       │       │   ├── jolokia.mod  
│       │       │   ├── jsp.mod  
│       │       │   ├── jstl.mod  
│       │       │   ├── jul-impl  
│       │       │   │   └── etc  
│       │       │   │       └── java-util-logging.properties  
│       │       │   ├── jul-impl.mod  
│       │       │   ├── jul-slf4j  
│       │       │   │   └── etc  
│       │       │   │       └── java-util-logging.properties  
│       │       │   ├── jul-slf4j.mod  
│       │       │   ├── jvm.mod  
│       │       │   ├── log4j2-api.mod  
│       │       │   ├── log4j2-impl  
│       │       │   │   └── resources  
│       │       │   │       └── log4j2.xml  
│       │       │   ├── log4j2-impl.mod  
│       │       │   ├── log4j2-slf4j.mod  
│       │       │   ├── log4j-impl  
│       │       │   │   └── resources  
│       │       │   │       └── log4j.xml  
│       │       │   ├── log4j-impl.mod  
│       │       │   ├── logback-access  
│       │       │   │   ├── jetty-logback-access.xml  
│       │       │   │   └── logback-access.xml  
│       │       │   ├── logback-access.mod  
│       │       │   ├── logback-impl  
│       │       │   │   └── resources  
│       │       │   │       └── logback.xml  
│       │       │   ├── logback-impl.mod  
│       │       │   ├── logging-jetty  
│       │       │   │   └── resources  
│       │       │   │       └── jetty-logging.properties  
│       │       │   ├── logging-jetty.mod  
│       │       │   ├── logging-jul.mod  
│       │       │   ├── logging-log4j2.mod  
│       │       │   ├── logging-log4j.mod  
│       │       │   ├── logging-logback.mod  
│       │       │   ├── logging-slf4j.mod  
│       │       │   ├── lowresources.mod  
│       │       │   ├── mail.mod  
│       │       │   ├── plus.mod  
│       │       │   ├── protonego-impl  
│       │       │   │   └── alpn-1.8.0_144.mod  
│       │       │   ├── proxy.mod  
│       │       │   ├── proxy-protocol.mod  
│       │       │   ├── proxy-protocol-ssl.mod  
│       │       │   ├── quickstart.mod  
│       │       │   ├── requestlog.mod  
│       │       │   ├── resources.mod  
│       │       │   ├── rewrite-compactpath.mod  
│       │       │   ├── rewrite-customizer.mod  
│       │       │   ├── rewrite.mod  
│       │       │   ├── security.mod  
│       │       │   ├── server.mod  
│       │       │   ├── servlet.mod  
│       │       │   ├── servlets.mod  
│       │       │   ├── session-cache-hash.mod  
│       │       │   ├── session-cache-null.mod  
│       │       │   ├── sessions  
│       │       │   │   ├── jdbc  
│       │       │   │   │   ├── datasource.mod  
│       │       │   │   │   └── driver.mod  
│       │       │   │   ├── mongo  
│       │       │   │   │   ├── address.mod  
│       │       │   │   │   └── uri.mod  
│       │       │   │   └── session-data-cache  
│       │       │   │       └── xmemcached.mod  
│       │       │   ├── sessions.mod  
│       │       │   ├── session-store-cache.mod  
│       │       │   ├── session-store-file.mod  
│       │       │   ├── session-store-gcloud.mod  
│       │       │   ├── session-store-hazelcast-embedded.mod  
│       │       │   ├── session-store-hazelcast-remote.mod  
│       │       │   ├── session-store-infinispan-embedded  
│       │       │   │   └── infinispan-embedded.xml  
│       │       │   ├── session-store-infinispan-embedded-910.mod  
│       │       │   ├── session-store-infinispan-embedded.mod  
│       │       │   ├── session-store-infinispan-remote  
│       │       │   │   └── resources  
│       │       │   │       └── hotrod-client.properties  
│       │       │   ├── session-store-infinispan-remote-910.mod  
│       │       │   ├── session-store-infinispan-remote.mod  
│       │       │   ├── session-store-jdbc.mod  
│       │       │   ├── session-store-mongo.mod  
│       │       │   ├── setuid.mod  
│       │       │   ├── slf4j-api.mod  
│       │       │   ├── slf4j-jul.mod  
│       │       │   ├── slf4j-log4j2.mod  
│       │       │   ├── slf4j-log4j.mod  
│       │       │   ├── slf4j-logback.mod  
│       │       │   ├── slf4j-simple-impl  
│       │       │   │   └── resources  
│       │       │   │       └── simplelogger.properties  
│       │       │   ├── slf4j-simple-impl.mod  
│       │       │   ├── spring.mod  
│       │       │   ├── ssl  
│       │       │   │   └── keystore  
│       │       │   ├── ssl.mod  
│       │       │   ├── stats.mod  
│       │       │   ├── stop.mod  
│       │       │   ├── threadlimit.mod  
│       │       │   ├── transactions.mod  
│       │       │   ├── unixsocket-forwarded.mod  
│       │       │   ├── unixsocket-http2c.mod  
│       │       │   ├── unixsocket-http.mod  
│       │       │   ├── unixsocket.mod  
│       │       │   ├── unixsocket-proxy-protocol.mod  
│       │       │   ├── unixsocket-secure.mod  
│       │       │   ├── webapp.mod  
│       │       │   └── websocket.mod  
│       │       ├── notice.html  
│       │       ├── README.TXT  
│       │       ├── resources  
│       │       ├── start.ini  
│       │       ├── start.jar  
│       │       ├── VERSION.txt  
│       │       └── webapps  
│       │           └── ROOT  
│       ├── bin  
│       │   ├── arthas-boot.jar  
│       │   │   ├── function-java.sh  
│       │   │   ├── jetty  
│       │   │   ├── jmap.sh  
│       │   │   ├── jstat.sh  
│       │   │   └── springboot  
│       │   ├── consul-client  
│       │   ├── create-jetty.sh  
│       │   ├── create-tomcat.sh  
│       │   ├── function-java.sh  
│       │   ├── jetty  
│       │   ├── restart-all-jetty.sh  
│       │   ├── restart-all-springboot.sh  
│       │   ├── show-busy-java-threads  
│       │   ├── show-duplicate-java-classes  
│       │   ├── springboot  
│       │   └── tomcat  
│       ├── flask  
│       │   ├── get-branch-info.py  
│       │   └── get-branch-info.sh  
│       ├── supervisord.d  
│       │   └── flask.ini  
│       └── tools  
│           ├── lame  
│           └── mp3gen  
├── nginx  
│   └── opt  
│       ├── bin  
│       │   ├── git-up-nginx.sh  
│       │   └── put-nginx-consul.sh  
│       └── supervisord.d  
│           └── nginx.ini  
├── nginx-lb  
│   └── opt  
│       ├── bin  
│       │   │   ├── check-upstream-conf-dev.sh  
│       │   │   ├── check-upstream-conf.sh  
│       │   ├── check-upstream-conf.sh  
│       │   └── git-up-nginx.sh  
│       └── supervisord.d  
│           └── nginx.ini  
├── node  
│   └── opt  
│       └── bin  
│           └── xue-client-web.sh  
├── node-server  
│   └── opt  
│       └── bin  
│           └── node-server  
├── ops  
│   └── opt  
│       └── bin  
│           │   └── sync.sh  
│           ├── del.sh  
│           ├── sync-jinj2.yaml  
│           ├── sync.sh  
│           └── sync.yaml  
├── php  
│   └── opt  
│       ├── bin  
│       │   └── laravel-swoole  
│       └── fonts  
│           └── simsun.ttf  
├── python  
│   └── opt  
│       └── bin  
│           ├── python  
│           └── restart-all-python.sh  
└── scripts  
 └── opt  
 ├── bin  
 │   └── xxl-job-executor  
 └── case  
 └── ops  
 └── xxl-job-executor  
 ├── application.properties  
 └── xxl-job-executor.jar
```
