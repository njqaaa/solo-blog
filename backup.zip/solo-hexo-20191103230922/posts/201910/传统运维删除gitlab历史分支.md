title: 传统运维 - 删除gitlab历史分支
date: '2019-10-24 15:53:42'
updated: '2019-10-24 19:40:02'
tags: [传统运维]
permalink: /articles/2019/10/24/1571903622675.html
---
### 自动删除除 master 外的历史分支

```
#!/bin/bash
day=$1
if [[ -z ${day} ]];then
    day=7
fi
history_time=$(date "+%Y-%m-%d %H" -d ''${day}' days ago')
history_timestamp=$(date -d "$history_time" +%s)
keywords="origin/master"
origin_branchs=$(git br -r | grep -v ${keywords})
i=0
for origin_branch in ${origin_branchs}
do
    last_commit_timestamp=$(git show --pretty=format:'%at' ${origin_branch} | head -n 1)
    if [[ ${last_commit_timestamp} -le ${history_timestamp} ]];then
        echo "待删除分支："${origin_branch}
        branch=$(echo ${origin_branch} | awk -F '/' '{print $NF}')
        git push origin :${branch}
        i=`expr $i + 1`
    fi
done
echo "总计本次删除："$i
```
